"""Константи інтерфейсу й протоколу."""
import re

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8080
DEFAULT_ACCENT = "#800020"
LOCAL_HOSTS = ("localhost", "127.0.0.1", "::1")
GROUP = "*"                       # ключ загального чату
DEFAULT_SOUND = "AxeMessage.mp3"

SIDEBAR_W = 300
HEADER_H = 62
GAP = 6
PROFILE_W = 620

RATE = 16000                      # частота запису голосових
MAX_REC_SEC = 60
SOUND_COOLDOWN = 4.0              # антиспам: звук не частіше ніж раз на N секунд
TOAST_SECONDS = 6
TOAST_W = 340
MAX_FILE_MB = 20
RENDER_LIMIT = 80                 # скільки останніх повідомлень малюємо в чаті
IMG_EXT = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp")
KEEP = object()                   # «не змінювати» в редакторі профілю

NAME_RE = re.compile(r"^[\w .\-]{3,24}$")
MONTHS = ["січня", "лютого", "березня", "квітня", "травня", "червня", "липня",
          "серпня", "вересня", "жовтня", "листопада", "грудня"]
