"""
Burgundy Chat — точка входу застосунку.

    python app.py            — запустити чат (сервер, якщо його немає, підніметься сам)
    python app.py --selftest — швидка перевірка файлів і шляхів (корисно для .exe)
"""
import sys
import threading

import storage


def _install_error_log():
    sys.excepthook = lambda *exc: (storage.log_exception(*exc), sys.__excepthook__(*exc))
    threading.excepthook = lambda a: storage.log_exception(a.exc_type, a.exc_value, a.exc_traceback)


def selftest():
    from ui.window import MainWindow
    app = MainWindow()
    app.update()
    print("frozen:", getattr(sys, "frozen", False))
    print("data dir:", storage.data_dir())
    for name in ("icon.png", "icon.ico", "AxeMessage.mp3"):
        import os
        print(f"assets/{name}:", os.path.isfile(storage.resource("assets", name)))
    print("default sound:", storage.default_sound() or "НЕ ЗНАЙДЕНО")
    print("sound ready:", app.notify_snd is not None)
    app.after(800, app.on_close)
    app.mainloop()


def main():
    _install_error_log()
    if "--selftest" in sys.argv:
        selftest()
        return
    from ui.window import MainWindow
    MainWindow().mainloop()


if __name__ == "__main__":
    main()
