"""
Burgundy Chat — сервер.

Працює самостійно (python server.py) або вбудований у програму (її запускає app.py,
якщо сервера на цьому комп'ютері ще немає). Потрібна лише стандартна бібліотека Python.

Акаунти й профілі лежать у SQLite (chat_users.db у папці даних програми).
Паролі зберігаються як PBKDF2-хеші. У кожного користувача постійний id, тому зміна
імені не створює «нового» користувача.

Адміністратор (необовʼязково): логін і пароль беруться зі змінних оточення
CHAT_ADMIN_NAME / CHAT_ADMIN_PASSWORD або з файлу admin.json у папці даних програми.
Акаунт створюється/оновлюється при кожному запуску. Якщо нічого не задано — адміністратора немає.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import socket
import sqlite3
import threading
import time
import traceback
from contextlib import closing

import storage
from consts import DEFAULT_PORT, GROUP

NAME_RE = re.compile(r"^[\w .\-]{3,24}$")
MID_RE = re.compile(r"^(\d+)\.(\d+)$")      # id повідомлення: «<id автора>.<лічильник>»

MAX_LINE = 48 * 1024 * 1024      # найбільший допустимий рядок протоколу
MAX_TEXT = 4000
MAX_AVATAR = 256 * 1024
MAX_BANNER = 1024 * 1024
MAX_SONG = 10 * 1024 * 1024
MAX_BIO = 300

USERS_SCHEMA = """CREATE TABLE {name}(
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    name_key TEXT NOT NULL UNIQUE,
    salt     BLOB NOT NULL,
    pw_hash  BLOB NOT NULL,
    is_admin INTEGER NOT NULL DEFAULT 0)"""

PROFILES_SCHEMA = """CREATE TABLE IF NOT EXISTS profiles(
    user_id   INTEGER PRIMARY KEY,
    bio       TEXT NOT NULL DEFAULT '',
    avatar    BLOB,
    banner    BLOB,
    song      BLOB,
    song_name TEXT NOT NULL DEFAULT '',
    rev       INTEGER NOT NULL DEFAULT 0)"""


def hash_pw(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)


def valid_name(name):
    return bool(NAME_RE.match(name)) and any(ch.isalnum() for ch in name)


def b64d(value, limit):
    """None — «прибрати», False — файл пошкоджений або завеликий."""
    if not value:
        return None
    try:
        raw = base64.b64decode(value, validate=True)
    except Exception:
        return False
    return raw if len(raw) <= limit else False


def b64e(raw):
    return base64.b64encode(raw).decode("ascii") if raw else ""


class ChatServer:
    def __init__(self, host="0.0.0.0", port=DEFAULT_PORT, db_file=None):
        self.host, self.port = host, port
        self.db_file = db_file or storage.db_file()
        self.lock = threading.Lock()       # sessions / by_uid
        self.db_lock = threading.Lock()    # записи в БД
        self.sessions = {}                 # socket -> id користувача
        self.by_uid = {}                   # id користувача -> socket
        self.wlocks = {}                   # socket -> Lock (великі повідомлення не перемішуються)
        self.listener = None
        self.running = False
        self.init_db()

    # ------------------------------------------------------------------ База
    def db_one(self, sql, args=()):
        with closing(sqlite3.connect(self.db_file)) as con:
            return con.execute(sql, args).fetchone()

    def db_all(self, sql, args=()):
        with closing(sqlite3.connect(self.db_file)) as con:
            return con.execute(sql, args).fetchall()

    def db_exec(self, sql, args=()):
        with self.db_lock, closing(sqlite3.connect(self.db_file)) as con, con:
            return con.execute(sql, args).lastrowid

    def init_db(self):
        with self.db_lock, closing(sqlite3.connect(self.db_file)) as con, con:
            exists = con.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='users'").fetchone()
            if not exists:
                con.execute(USERS_SCHEMA.format(name="users"))
            else:
                cols = [r[1] for r in con.execute("PRAGMA table_info(users)")]
                if "email" in cols:           # дуже стара база (з поштою)
                    con.execute(USERS_SCHEMA.format(name="users_new"))
                    con.execute("INSERT INTO users_new(id, username, name_key, salt, pw_hash) "
                                "SELECT id, username, name_key, salt, pw_hash FROM users")
                    con.execute("DROP TABLE users")
                    con.execute("ALTER TABLE users_new RENAME TO users")
                elif "is_admin" not in cols:
                    con.execute("ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0")
            con.execute(PROFILES_SCHEMA)
            self._ensure_admin(con, storage.admin_credentials())

    @staticmethod
    def _ensure_admin(con, creds):
        """Акаунт адміністратора: створюється або оновлюється за заданими логіном і паролем."""
        if creds is None:
            con.execute("UPDATE users SET is_admin=0")
            return
        name, password = creds
        key = " ".join(name.split()).casefold()
        row = con.execute("SELECT id, salt, pw_hash FROM users WHERE name_key=?", (key,)).fetchone()
        if row is None:
            salt = os.urandom(16)
            con.execute("INSERT INTO users(username, name_key, salt, pw_hash, is_admin) "
                        "VALUES(?,?,?,?,1)", (name, key, salt, hash_pw(password, salt)))
        else:
            uid, salt, pw_hash = row
            if not hmac.compare_digest(hash_pw(password, salt), pw_hash):
                salt = os.urandom(16)
                con.execute("UPDATE users SET salt=?, pw_hash=? WHERE id=?",
                            (salt, hash_pw(password, salt), uid))
            con.execute("UPDATE users SET is_admin=1 WHERE id=?", (uid,))
        con.execute("UPDATE users SET is_admin=0 WHERE name_key != ?", (key,))

    # ----------------------------------------------------------------- Мережа
    def send(self, sock, line):
        wl = self.wlocks.get(sock)
        if wl is None:
            return
        try:
            with wl:
                sock.sendall((line + "\n").encode("utf-8"))
        except OSError:
            pass

    def broadcast(self, line, exclude=None):
        with self.lock:
            targets = [s for s in self.sessions if s is not exclude]
        for s in targets:
            self.send(s, line)

    def send_users(self):
        """Розсилає всім список акаунтів: [[id, імʼя, онлайн, версія_аватара], ...]."""
        rows = self.db_all("SELECT u.id, u.username, COALESCE(p.rev, 0) FROM users u "
                           "LEFT JOIN profiles p ON p.user_id = u.id ORDER BY u.id")
        with self.lock:
            online = set(self.by_uid)
        self.broadcast("USERS@" + json.dumps([[r[0], r[1], r[0] in online, r[2]] for r in rows]))

    @staticmethod
    def kick(sock):
        for action in (lambda: sock.shutdown(socket.SHUT_RDWR), sock.close):
            try:
                action()
            except OSError:
                pass

    # ------------------------------------------------------------- Авторизація
    def login_ok(self, sock, uid, name, admin):
        with self.lock:
            old = self.by_uid.get(uid)
            self.sessions[sock] = uid
            self.by_uid[uid] = sock
        if old is not None and old is not sock:
            self.send(old, "ERR@Вхід виконано з іншого пристрою")
            self.kick(old)
        self.send(sock, "AUTH_OK@" + json.dumps({"id": uid, "username": name, "admin": admin}))
        self.send_users()
        self.broadcast(f"SYS@{name} в мережі", exclude=sock)

    def do_login(self, sock, data):
        login = " ".join(str(data.get("login", "")).split())
        password = str(data.get("password", ""))
        row = self.db_one("SELECT id, username, salt, pw_hash, is_admin FROM users "
                          "WHERE name_key=?", (login.casefold(),))
        if row and hmac.compare_digest(hash_pw(password, row[2]), row[3]):
            self.login_ok(sock, row[0], row[1], bool(row[4]))
        else:
            time.sleep(0.7)  # проти підбору пароля
            self.send(sock, "AUTH_ERR@Невірне імʼя або пароль")

    def do_register(self, sock, data):
        name = " ".join(str(data.get("username", "")).split())
        password = str(data.get("password", ""))
        if not valid_name(name):
            self.send(sock, "AUTH_ERR@Імʼя: 3–24 символи (літери, цифри, пробіл, . _ -)")
            return
        if len(password) < 6:
            self.send(sock, "AUTH_ERR@Пароль має містити щонайменше 6 символів")
            return
        salt = os.urandom(16)
        try:
            uid = self.db_exec(
                "INSERT INTO users(username, name_key, salt, pw_hash) VALUES(?,?,?,?)",
                (name, name.casefold(), salt, hash_pw(password, salt)))
        except sqlite3.IntegrityError:
            self.send(sock, "AUTH_ERR@Це імʼя вже зайняте")
            return
        self.login_ok(sock, uid, name, False)

    # ------------------------------------------------------------------ Профілі
    def do_profile_set(self, sock, uid, data):
        sets, args, new_avatar = [], [], False
        if "bio" in data:
            sets.append("bio=?")
            args.append(str(data["bio"]).strip()[:MAX_BIO])
        for key, limit in (("avatar", MAX_AVATAR), ("banner", MAX_BANNER), ("song", MAX_SONG)):
            if key in data:
                raw = b64d(data[key], limit)
                if raw is False:
                    self.send(sock, f"ERR@Файл ({key}) завеликий або пошкоджений")
                    return
                sets.append(f"{key}=?")
                args.append(raw)
                new_avatar = new_avatar or key == "avatar"
                if key == "song":
                    sets.append("song_name=?")
                    args.append(str(data.get("song_name", ""))[:80] if raw else "")
        if not sets:
            return
        self.db_exec("INSERT OR IGNORE INTO profiles(user_id) VALUES(?)", (uid,))
        if new_avatar:
            sets.append("rev=rev+1")
        self.db_exec(f"UPDATE profiles SET {', '.join(sets)} WHERE user_id=?", (*args, uid))
        self.send(sock, "OK@Профіль збережено")
        if new_avatar:
            self.send_users()

    def _target_id(self, value):
        try:
            tid = int(value)
        except ValueError:
            return None
        return tid if self.db_one("SELECT 1 FROM users WHERE id=?", (tid,)) else None

    def send_profile(self, sock, target):
        tid = self._target_id(target)
        if tid is None:
            return
        row = self.db_one("SELECT bio, avatar, banner, song_name, COALESCE(length(song), 0) "
                          "FROM profiles WHERE user_id=?", (tid,))
        bio, avatar, banner, song_name, song_len = row or ("", None, None, "", 0)
        self.send(sock, "PROFILE@" + json.dumps({
            "id": tid, "bio": bio, "avatar": b64e(avatar), "banner": b64e(banner),
            "song_name": song_name, "has_song": song_len > 0}))

    def send_avatar(self, sock, target):
        tid = self._target_id(target)
        if tid is not None:
            row = self.db_one("SELECT avatar, rev FROM profiles WHERE user_id=?", (tid,))
            avatar, rev = row or (None, 0)
            self.send(sock, f"AVATAR@{tid}@{rev}@{b64e(avatar)}")

    def send_song(self, sock, target):
        tid = self._target_id(target)
        row = self.db_one("SELECT song, song_name FROM profiles WHERE user_id=?", (tid,)) if tid else None
        if row and row[0]:
            self.send(sock, "SONG@" + json.dumps({"id": tid, "name": row[1], "b64": b64e(row[0])}))
        else:
            self.send(sock, "ERR@У цього користувача немає пісні в профілі")

    # --------------------------------------------------------------- Повідомлення
    def do_rename(self, sock, uid, new):
        new = " ".join(new.split())
        if not valid_name(new):
            self.send(sock, "ERR@Імʼя: 3–24 символи (літери, цифри, пробіл, . _ -)")
            return
        old, is_admin = self.db_one("SELECT username, is_admin FROM users WHERE id=?", (uid,))
        if is_admin:
            self.send(sock, "ERR@Адміністратор не може змінити імʼя")
            return
        if new == old:
            return
        try:
            self.db_exec("UPDATE users SET username=?, name_key=? WHERE id=?",
                         (new, new.casefold(), uid))
        except sqlite3.IntegrityError:
            self.send(sock, "ERR@Це імʼя вже зайняте")
            return
        self.broadcast(f"SYS@{old} тепер {new}")
        self.send_users()

    def route(self, sock, uid, target, out, quiet=False):
        """Надсилає out в загальний чат (всім, крім автора) або одному співрозмовнику."""
        if target == GROUP:
            self.broadcast(out, exclude=sock)
            return
        try:
            tid = int(target)
        except ValueError:
            return
        if tid == uid:
            return
        with self.lock:
            dest = self.by_uid.get(tid)
        if dest is not None:
            self.send(dest, out)
        elif not quiet:
            self.send(sock, "ERR@Користувач не в мережі")

    @staticmethod
    def own_mid(mid, uid):
        """id повідомлення має вигляд «<id автора>.<число>»; автор — лише власник сесії."""
        m = MID_RE.match(mid)
        return bool(m) and int(m.group(1)) == uid

    def process(self, sock, line):
        cmd, _, rest = line.partition("@")
        auth = {"LOGIN": self.do_login, "REGISTER": self.do_register}
        if cmd in auth:
            try:
                data = json.loads(rest)
            except ValueError:
                return
            if isinstance(data, dict):
                auth[cmd](sock, data)
            return

        with self.lock:
            uid = self.sessions.get(sock)
        if uid is None:
            return  # не авторизований

        if cmd == "RENAME":
            self.do_rename(sock, uid, rest)
        elif cmd == "MSG":
            p = rest.split("@", 2)                   # mid, кому, текст
            if len(p) == 3 and self.own_mid(p[0], uid) and len(p[2]) <= MAX_TEXT:
                self.route(sock, uid, p[1], f"MSG@{p[0]}@{uid}@{p[1]}@{p[2]}")
        elif cmd in ("IMG", "FILE", "VOICE"):
            p = rest.split("@", 3)                   # mid, кому, імʼя/тривалість, дані
            if len(p) == 4 and self.own_mid(p[0], uid):
                self.route(sock, uid, p[1], f"{cmd}@{p[0]}@{uid}@{p[1]}@{p[2]}@{p[3]}")
        elif cmd == "EDIT":
            p = rest.split("@", 2)                   # mid, кому, новий текст
            if len(p) == 3 and self.own_mid(p[0], uid) and len(p[2]) <= MAX_TEXT:
                self.route(sock, uid, p[1], f"EDIT@{p[0]}@{uid}@{p[1]}@{p[2]}", quiet=True)
        elif cmd == "DEL":
            p = rest.split("@", 1)                   # mid, кому
            if len(p) == 2 and self.own_mid(p[0], uid):
                self.route(sock, uid, p[1], f"DEL@{p[0]}@{uid}@{p[1]}", quiet=True)
        elif cmd == "PROFILE_SET":
            try:
                data = json.loads(rest)
            except ValueError:
                return
            if isinstance(data, dict):
                self.do_profile_set(sock, uid, data)
        elif cmd == "PROFILE_GET":
            self.send_profile(sock, rest)
        elif cmd == "AVATAR_GET":
            self.send_avatar(sock, rest)
        elif cmd == "SONG_GET":
            self.send_song(sock, rest)

    def handle_client(self, sock):
        buf = bytearray()
        scan = 0
        try:
            while True:
                chunk = sock.recv(262144)
                if not chunk:
                    break
                buf += chunk
                while True:
                    i = buf.find(b"\n", scan)
                    if i < 0:
                        scan = len(buf)  # не перечитуємо вже переглянуте
                        break
                    line = bytes(buf[:i])
                    del buf[:i + 1]
                    scan = 0
                    if line.strip():
                        try:
                            self.process(sock, line.decode("utf-8", errors="replace"))
                        except Exception:
                            traceback.print_exc()
                if len(buf) > MAX_LINE:
                    break  # занадто велике повідомлення — розриваємо зʼєднання
        except OSError:
            pass
        finally:
            self._disconnect(sock)

    def _disconnect(self, sock):
        left = None
        with self.lock:
            uid = self.sessions.pop(sock, None)
            if uid is not None and self.by_uid.get(uid) is sock:
                del self.by_uid[uid]
                left = uid
        self.wlocks.pop(sock, None)
        try:
            sock.close()
        except OSError:
            pass
        if left is not None and self.running:
            row = self.db_one("SELECT username FROM users WHERE id=?", (left,))
            if row:
                self.broadcast(f"SYS@{row[0]} вийшов(ла) з мережі")
            self.send_users()

    # ------------------------------------------------------------------ Запуск
    def start(self):
        """Починає слухати порт і приймає зʼєднання у фоновому потоці. OSError — порт зайнятий."""
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.listener.bind((self.host, self.port))
        except OSError:
            self.listener.close()
            raise
        self.listener.listen(20)
        self.running = True
        threading.Thread(target=self._accept_loop, daemon=True).start()

    def _accept_loop(self):
        while self.running:
            try:
                client, addr = self.listener.accept()
            except OSError:
                break
            print(f"Підключився клієнт: {addr}")
            self.wlocks[client] = threading.Lock()
            threading.Thread(target=self.handle_client, args=(client,), daemon=True).start()

    def stop(self):
        self.running = False
        if self.listener:
            try:
                self.listener.close()
            except OSError:
                pass
        with self.lock:
            socks = list(self.sessions) + list(self.wlocks)
        for s in set(socks):
            self.kick(s)


def lan_address():
    """IP-адреса цього комп'ютера в локальній мережі (для друзів)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def main():
    server = ChatServer("0.0.0.0", DEFAULT_PORT)
    server.start()
    print(f"Сервер запущено на 0.0.0.0:{DEFAULT_PORT}  (адреса в локальній мережі: "
          f"{lan_address()}:{DEFAULT_PORT})")
    print(f"База даних: {server.db_file}")
    creds = storage.admin_credentials()
    print(f"Адміністратор: {creds[0] if creds else 'не налаштований (див. README)'}")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        server.stop()


if __name__ == "__main__":
    main()
