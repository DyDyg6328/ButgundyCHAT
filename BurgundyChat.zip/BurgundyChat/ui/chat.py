"""Область повідомлень: фон, малювання, прокрутка, анімації появи."""
import datetime
import storage
import theme
import time
import tkinter as tk

from PIL import Image
from PIL import ImageTk
import customtkinter as ctk

from consts import GAP, GROUP, RENDER_LIMIT
from ui.helpers import day_label, ease_in_out


class ChatViewMixin:
    def _load_bg_source(self):
        self.bg_src = None
        path = storage.asset_path("backgrounds", self.cfg["bg_file"])
        if self.cfg["bg_mode"] == "image" and path:
            try:
                img = Image.open(path).convert("RGB")
                img.thumbnail((1920, 1080))
                self.bg_src = img
            except Exception:
                self.cfg["bg_mode"] = "pattern"

    def _update_bg(self):
        if not self.ui_ready:
            return
        w, h = self.chat.winfo_width(), self.chat.winfo_height()
        if w < 10 or h < 10:
            return
        if self.cfg["bg_mode"] == "image" and self.bg_src is not None:
            img = theme.fit_bg(self.bg_src, w, h, self.cfg["bg_dim"], self.cfg["mode"])
        else:
            img = theme.pattern_image(w, h, self.cfg["mode"], self.cfg["accent"])
        self.bg_photo = ImageTk.PhotoImage(img)
        self.chat.itemconfigure(self.bg_item, image=self.bg_photo)
        self._sync_bg()

    def _sync_bg(self):
        self.chat.coords(self.bg_item, self.chat.canvasx(0), self.chat.canvasy(0))

    def _on_yscroll(self, lo, hi):
        self.scrollbar.set(lo, hi)
        self._sync_bg()

    def _on_chat_resize(self, event):
        if self.resize_job:
            self.after_cancel(self.resize_job)
        self.resize_job = self.after(60, self._after_resize)

    def _after_resize(self):
        self.resize_job = None
        self._update_bg()
        self._relayout()

    def sys_msg(self, text, chat=None):
        self.add_msg(chat or self.current, "system", "text", text=text)

    def add_msg(self, chat, kind, mtype="text", **kw):
        self._ensure_chat(chat)
        self.msg_seq += 1
        rec = {"id": self.msg_seq, "kind": kind, "type": mtype, "ts": time.time(),
               "chat": chat}
        rec.update(kw)
        c = self.chats[chat]
        c["msgs"].append(rec)
        if rec.get("mid"):
            self.mid_index[rec["mid"]] = rec
        if len(c["msgs"]) > 300:
            for old in c["msgs"][:100]:
                self.mid_index.pop(old.get("mid"), None)
            del c["msgs"][:100]

        if self.ui_ready and chat == self.current:
            near = self.chat.yview()[1] > 0.97
            it = self._append_item(rec)
            self._relayout()
            self._animate_in(it)
            if near or kind == "own":
                self._scroll_bottom(True)
        elif kind not in ("own", "system"):
            c["unread"] += 1
        if kind != "system" and self.ui_ready:
            self._refresh_row(chat)
            self._layout_chat_list()
        return rec

    def _clear_items(self):
        for it in self.items:
            try:
                self.chat.delete(it["win"])
                if it.get("av"):
                    self.chat.delete(it["av"])
                it["widget"].destroy()
            except tk.TclError:
                pass
        self.items = []
        self._last_day = None
        self._last_wrap = 0

    def _render_chat(self, key, slide=False, keep_scroll=False):
        if not self.ui_ready:
            return
        top = self.chat.yview()[0]
        self._clear_items()
        for rec in self.chats[key]["msgs"][-RENDER_LIMIT:]:
            self._append_item(rec)
        self._relayout(bottom=not keep_scroll)
        if keep_scroll:
            self.chat.yview_moveto(top)
        if slide and self.items:
            for it in self.items:
                it["ox"] = 46

            def fn(t):
                for it in self.items:
                    it["ox"] = 46 * (1 - t)
                    self._place(it)

            self.tween("switch", 200, fn)

    def _append_item(self, rec):
        day = datetime.date.fromtimestamp(rec["ts"])
        if day != self._last_day:
            self._last_day = day
            self._add_canvas_item(self._date_pill(day), "system", [], None, None)
        if rec["kind"] == "system":
            pill = ctk.CTkFrame(self.chat, fg_color=self.p["pill"], corner_radius=12)
            lbl = ctk.CTkLabel(pill, text=rec["text"], text_color=self.p["muted"],
                               font=self.font(12, slant="italic"), wraplength=self._wrap())
            lbl.pack(padx=14, pady=5)
            return self._add_canvas_item(pill, "system", [lbl], None, rec)
        widget, labels = self._bubble(rec)
        self._bind_bubble(widget, rec)
        uid = rec.get("author") if (rec["kind"] == "other" and rec["chat"] == GROUP) else None
        return self._add_canvas_item(widget, rec["kind"], labels, uid, rec)

    def _date_pill(self, day):
        pill = ctk.CTkFrame(self.chat, fg_color=self.p["pill"], corner_radius=12)
        ctk.CTkLabel(pill, text=day_label(day), text_color=self.p["muted"],
                     font=self.font(12, "bold")).pack(padx=14, pady=4)
        return pill

    def _add_canvas_item(self, widget, kind, labels, uid, rec):
        anchor = {"own": "ne", "other": "nw", "system": "n"}[kind]
        win = self.chat.create_window(0, 0, window=widget, anchor=anchor)
        it = {"win": win, "widget": widget, "kind": kind, "labels": labels,
              "av": None, "uid": uid, "rec": rec, "ox": 0, "oy": 0, "y": 0}
        if kind == "other" and rec and rec["chat"] == GROUP:
            it["photo"] = ImageTk.PhotoImage(self.avatar_pil(uid, 32))
            it["av"] = self.chat.create_image(0, 0, anchor="nw", image=it["photo"])
            self.chat.tag_bind(it["av"], "<Button-1>",
                               lambda e, u=uid: self.open_profile_view(u) if u else None)
        self.items.append(it)
        return it

    def _chat_width(self):
        w = self.chat.winfo_width()
        return w if w > 50 else 700

    def _wrap(self):
        return max(200, int(self._chat_width() * 0.62) - (44 if self.current == GROUP else 0))

    def _relayout(self, bottom=False):
        if not self.ui_ready:
            return
        w = self._chat_width()
        wrap = self._wrap()
        if wrap != self._last_wrap:
            self._last_wrap = wrap
            for it in self.items:
                for lbl in it["labels"]:
                    lbl.configure(wraplength=wrap)
        self.update_idletasks()
        y = 12
        for it in self.items:
            it["y"] = y
            y += it["widget"].winfo_reqheight() + GAP
            self._place(it, w)
        view_h = max(self.chat.winfo_height(), 1)
        self._region_h = max(y + 8, view_h)
        self.chat.configure(scrollregion=(0, 0, w, self._region_h))
        if bottom:
            self.chat.yview_moveto(1.0)
        self._sync_bg()

    def _place(self, it, w=None):
        w = w or self._chat_width()
        k = it["kind"]
        if k == "own":
            x = w - 16
        elif k == "other":
            x = 16 + (44 if it.get("av") else 0)
        else:
            x = w // 2
        self.chat.coords(it["win"], x + it["ox"], it["y"] + it["oy"])
        if it.get("av"):
            self.chat.coords(it["av"], 16 + it["ox"], it["y"] + it["oy"])

    def _animate_in(self, it):
        def fn(t):
            it["oy"] = 26 * (1 - t)
            self._place(it)

        self.tween(("in", it["win"]), 230, fn)

    def _scroll_bottom(self, animated=True):
        view_h = max(self.chat.winfo_height(), 1)
        target = max(0.0, self._region_h - view_h)
        start = self.chat.canvasy(0)
        if not animated or abs(target - start) < 2:
            self.chat.yview_moveto(1.0)
            return
        region = self._region_h
        self.tween("scroll", 260, lambda t: self.chat.yview_moveto(
            (start + (target - start) * t) / region), ease=ease_in_out)

    def _in_chat(self, w):
        while w is not None:
            if w is self.chat:
                return True
            w = getattr(w, "master", None)
        return False

    def _on_wheel(self, event):
        try:
            w = self.winfo_containing(event.x_root, event.y_root)
        except Exception:
            return
        if self._in_chat(w):
            self._scroll_by(-event.delta * 0.75)

    def _wheel_linux(self, px):
        try:
            w = self.winfo_containing(*self.winfo_pointerxy())
        except Exception:
            return
        if self._in_chat(w):
            self._scroll_by(px)

    def _scroll_by(self, px):
        if not self.ui_ready:
            return
        view_h = max(self.chat.winfo_height(), 1)
        region = self._region_h
        if region <= view_h:
            return
        cur = self.chat.canvasy(0)
        base = self._scroll_goal if "scroll" in self._tweens else cur
        goal = max(0.0, min(region - view_h, base + px))
        self._scroll_goal = goal
        self.tween("scroll", 200, lambda t: self.chat.yview_moveto(
            (cur + (goal - cur) * t) / region))
