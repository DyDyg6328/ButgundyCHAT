"""Головне вікно: збирає всі частини інтерфейсу."""
import os
import queue
import shutil
import sys
import tempfile
import threading
import tkinter as tk
import traceback

import customtkinter as ctk

import storage
import theme
from consts import GROUP, SIDEBAR_W
from ui.auth import AuthMixin
from ui.base import BaseMixin
from ui.bubbles import BubblesMixin
from ui.chat import ChatViewMixin
from ui.composer import ComposerMixin
from ui.layout import LayoutMixin
from ui.lightbox import LightboxMixin
from ui.media import MediaMixin
from ui.messages import MessagesMixin
from ui.net import NetMixin
from ui.notify import NotifyMixin
from ui.pages import PagesMixin
from ui.profile import ProfileMixin
from ui.settings import SettingsMixin
from ui.sidebar import SidebarMixin


class MainWindow(
        LightboxMixin, MessagesMixin, LayoutMixin, SidebarMixin, ChatViewMixin, BubblesMixin,
        ComposerMixin, MediaMixin, NotifyMixin, PagesMixin, SettingsMixin, ProfileMixin,
        AuthMixin, NetMixin, BaseMixin, ctk.CTk):
    """Головне вікно. Уся логіка розкладена по mixin-класах у пакеті ui/."""

    def __init__(self):
        super().__init__()
        storage.migrate_legacy()
        self.cfg = storage.load_settings()
        self.p = theme.make_palette(self.cfg["mode"], self.cfg["accent"])
        ctk.set_appearance_mode(self.cfg["mode"])
        self.title("Burgundy Chat")
        self.geometry("1000x660")
        self.minsize(760, 520)
        self._set_icon()
        self.configure(fg_color=self.p["bg"])

        # акаунт і мережа
        self.username = ""
        self.my_id = None
        self.login_line = None
        self.pending_cred = None
        self.is_admin = False
        self.embedded_server = None
        self.auth_visible = True
        self.sock = None
        self.send_lock = threading.Lock()
        self.incoming = queue.Queue()

        # користувачі й профілі
        self.users = {}           # id -> імʼя (без себе)
        self.online = set()
        self.avatars = {}         # id -> PIL або None
        self.avatar_have = {}     # id -> версія аватара, яку ми маємо
        self.avatar_wait = {}     # id -> версія, яку вже запросили
        self.profiles = {}        # id -> {"bio","avatar","banner","song_name","has_song"}
        self.songs = {}           # id -> (назва, байти)
        self.want_song = None

        # чати
        self.chats = {GROUP: {"msgs": [], "unread": 0}}
        self.current = GROUP
        self.msg_seq = 0
        self.mid_seq = 0
        self.mid_index = {}        # id повідомлення -> запис (для редагування й видалення)
        self.editing = None        # повідомлення, яке зараз редагується
        self.lightbox = None
        self.items = []
        self.chat_rows = {}
        self._img_cache = {}
        self._fonts = {}
        self._tweens = {}
        self._last_wrap = 0
        self._last_day = None
        self._region_h = 1
        self._scroll_goal = 0.0
        self.ui_ready = False
        self.resize_job = None
        self.bg_src = None
        self.bg_photo = None

        # меню, сторінки
        self.menu_open = False
        self.menu_x = -SIDEBAR_W
        self.page = None
        self.page_name = None
        self._old_page = None
        self.pv = None
        self.edit = None

        # аудіо / голосові / сповіщення
        self.tmpdir = tempfile.mkdtemp(prefix="burgundy_")
        self.mixer_ok = False
        self.notify_snd = None
        self.player = None
        self.recording = False
        self.rec_stream = None
        self.rec_frames = []
        self.rec_target = GROUP
        self.rec_started = 0.0
        self.last_sound = 0.0
        self.toast = None
        self.toast_job = None
        self.toast_count = 0
        self.toast_chat = None
        self.toast_widgets = {}
        self._debounce_jobs = {}

        self._load_bg_source()
        self._build_ui()
        self._init_sound()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.bind_all("<MouseWheel>", self._on_wheel)
        self.bind_all("<Button-4>", lambda e: self._wheel_linux(-90))
        self.bind_all("<Button-5>", lambda e: self._wheel_linux(90))

        self.connect_to_server(autostart=False, quiet=True)   # тиха перевірка: чи є вже сервер
        self.after(100, self._process_queue)

    def _set_icon(self):
        png, ico = storage.resource("assets", "icon.png"), storage.resource("assets", "icon.ico")
        try:
            self._icon_photo = tk.PhotoImage(file=png)
            self.iconphoto(True, self._icon_photo)
        except tk.TclError:
            pass
        if sys.platform == "win32" and os.path.isfile(ico):
            self.iconbitmap(ico)
            self.after(300, lambda: self.iconbitmap(ico))   # CTk підставляє свою іконку з затримкою

    def report_callback_exception(self, exc, val, tb):
        traceback.print_exception(exc, val, tb)
        storage.log_exception(exc, val, tb)

    def on_close(self):
        self._save_cfg()
        self._close_toast(now=True)
        if self.recording:
            self._stop_record(send=False)
        self._stop_player()
        self._close_socket()
        if self.embedded_server is not None:
            self.embedded_server.stop()
        shutil.rmtree(self.tmpdir, ignore_errors=True)
        self.destroy()
