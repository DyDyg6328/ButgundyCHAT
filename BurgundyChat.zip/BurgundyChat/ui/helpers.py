"""Дрібні допоміжні функції інтерфейсу."""
import ctypes
import datetime
import os
import subprocess
import sys

from consts import MONTHS


def ease_out(t):
    return 1 - (1 - t) ** 3


def ease_in_out(t):
    return 3 * t * t - 2 * t * t * t


def day_label(day):
    today = datetime.date.today()
    if day == today:
        return "Сьогодні"
    if day == today - datetime.timedelta(days=1):
        return "Вчора"
    text = f"{day.day} {MONTHS[day.month - 1]}"
    return text if day.year == today.year else f"{text} {day.year}"


def open_external(path):
    """Відкриває файл у програмі за замовчуванням (для mp4 тощо)."""
    try:
        if sys.platform == "win32":
            os.startfile(path)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


def set_alpha(win, value):
    try:
        win.attributes("-alpha", value)
    except Exception:
        pass


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]
