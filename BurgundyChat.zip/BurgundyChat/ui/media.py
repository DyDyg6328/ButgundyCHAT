"""Запис голосових, відтворення аудіо, звук сповіщень."""
import base64
import io
import math
import os
import re
import time
import tkinter as tk
import wave

import storage
from theme import mix
from consts import MAX_REC_SEC, RATE
from ui.optional import np, pygame, sd


class MediaMixin:
    def _start_record(self):
        if sd is None:
            self.sys_msg("Для голосових: pip install sounddevice numpy")
            return
        if not self.sock:
            self.sys_msg("Помилка: немає зʼєднання з сервером")
            return
        if not self._can_send_to_current():
            return
        self.rec_frames = []
        try:
            self.rec_stream = sd.InputStream(
                samplerate=RATE, channels=1, dtype="int16",
                callback=lambda indata, frames, t, status: self.rec_frames.append(indata.copy()))
            self.rec_stream.start()
        except Exception as e:
            self.rec_stream = None
            self.sys_msg(f"Не вдалося увімкнути мікрофон: {e}")
            return
        self.recording = True
        self.rec_target = self.current
        self.rec_started = time.time()
        self.action_btn.configure(text="⏹")
        self._tick_record()

    def _tick_record(self):
        if not self.recording:
            return
        elapsed = time.time() - self.rec_started
        if elapsed >= MAX_REC_SEC:
            self._stop_record()
            return
        k = (math.sin(time.time() * 5) + 1) / 2   # пульсація кнопки запису
        self.action_btn.configure(fg_color=mix(self.p["err"], self.p["accent"], k * 0.45))
        self.message_entry.configure(
            placeholder_text=f"● Запис… {self._fmt_dur(elapsed)} — натисніть ⏹, щоб надіслати")
        self.after(50, self._tick_record)

    def _stop_record(self, send=True):
        self.recording = False
        stream, self.rec_stream = self.rec_stream, None
        if stream:
            try:
                stream.stop()
                stream.close()
            except Exception:
                pass
        try:
            self.action_btn.configure(fg_color=self.p["accent"])
            self.action_btn._fx_cur = self.p["accent"]
            self.message_entry.configure(placeholder_text="Напишіть повідомлення…")
            self._update_action()
        except tk.TclError:
            pass
        if not send or not self.rec_frames:
            return
        data = np.concatenate(self.rec_frames)
        dur = len(data) / RATE
        if dur < 0.5:
            self.sys_msg("Занадто коротке голосове повідомлення")
            return
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(RATE)
            w.writeframes(data.tobytes())
        raw = buf.getvalue()
        target = self.rec_target
        b64 = base64.b64encode(raw).decode("ascii")
        mid = self._new_mid()
        if self._send_raw(f"VOICE@{mid}@{target}@{int(round(dur))}@{b64}\n"):
            self.add_msg(target, "own", "voice", raw=raw, dur=dur, mid=mid)
        else:
            self.sys_msg("Помилка відправлення: немає зʼєднання з сервером")

    def _init_sound(self):
        if pygame is None:
            self.sys_msg("Для звуку й відтворення: pip install pygame")
            return
        try:
            pygame.mixer.init()
            self.mixer_ok = True
        except Exception as e:
            self.sys_msg(f"Звук недоступний: {e}")
            return
        self._load_notify_sound()

    def _load_notify_sound(self):
        self.notify_snd = None
        if not self.mixer_ok:
            return
        custom = storage.asset_path("sounds", self.cfg["sound_file"])
        path = custom if custom and os.path.isfile(custom) else storage.default_sound()
        if not path:
            return
        try:
            self.notify_snd = pygame.mixer.Sound(path)
            self.notify_snd.set_volume(self.cfg["volume"])
        except Exception as e:
            self.sys_msg(f"Не вдалося завантажити звук сповіщення: {e}")

    def _play_notify_sound(self):
        if self.notify_snd is not None:
            try:
                self.notify_snd.set_volume(self.cfg["volume"])
                self.notify_snd.play()
            except Exception:
                pass

    def _audio_len(self, path):
        try:
            if os.path.getsize(path) <= 12 * 1024 * 1024:
                return pygame.mixer.Sound(path).get_length()
        except Exception:
            pass
        return 0

    def _play(self, pid, kind, raw, btn=None, bar=None, ext=".mp3"):
        """kind: 'voice' (WAV) або 'music' (mp3). Повторне натискання зупиняє."""
        if not self.mixer_ok:
            self.sys_msg("Для відтворення: pip install pygame")
            return
        if self.player and self.player["pid"] == pid:
            self._stop_player()
            return
        self._stop_player()
        try:
            if kind == "voice":
                snd = pygame.mixer.Sound(file=io.BytesIO(raw))
                snd.set_volume(1.0)
                pl = {"kind": "voice", "snd": snd, "ch": snd.play(), "dur": snd.get_length()}
            else:
                path = os.path.join(self.tmpdir, re.sub(r"\W", "_", pid) + ext)
                with open(path, "wb") as f:
                    f.write(raw)
                pygame.mixer.music.load(path)
                pygame.mixer.music.set_volume(1.0)
                pygame.mixer.music.play()
                pl = {"kind": "music", "dur": self._audio_len(path)}
        except Exception as e:
            self.sys_msg(f"Не вдалося відтворити: {e}")
            return
        pl.update(pid=pid, btn=btn, bar=bar, start=time.time())
        self.player = pl
        if btn is not None:
            btn.configure(text="■")
        self._player_tick()

    def _attach_player(self, pid, btn, bar):
        """Після перемальовування чату привʼязуємо нові віджети до поточного відтворення."""
        pl = self.player
        if pl and pl["pid"] == pid:
            pl["btn"], pl["bar"] = btn, bar
            btn.configure(text="■")

    def _player_tick(self):
        pl = self.player
        if not pl:
            return
        try:
            if pl["kind"] == "voice":
                busy = pl["ch"].get_busy()
                pos = time.time() - pl["start"]
            else:
                busy = pygame.mixer.music.get_busy()
                pos = pygame.mixer.music.get_pos() / 1000.0
            if pl.get("bar") is not None and pl["dur"]:
                pl["bar"].set(min(1.0, pos / pl["dur"]))
        except Exception:
            busy = False
        if not busy:
            self._stop_player()
            return
        self.after(100, self._player_tick)

    def _stop_player(self):
        pl, self.player = self.player, None
        if not pl:
            return
        try:
            if pl["kind"] == "voice":
                pl["snd"].stop()
            else:
                pygame.mixer.music.stop()
        except Exception:
            pass
        try:
            if pl.get("btn") is not None:
                pl["btn"].configure(text="▶")
            if pl.get("bar") is not None:
                pl["bar"].set(0)
        except Exception:
            pass
