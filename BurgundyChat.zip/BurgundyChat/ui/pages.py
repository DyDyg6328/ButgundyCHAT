"""Сторінки поверх вікна (налаштування, профіль) і спільні віджети для них."""
import tkinter as tk

import customtkinter as ctk

from consts import HEADER_H


class PagesMixin:
    def _open_page(self, name, builder, instant=False):
        for old in (self.page, self._old_page):
            if old is not None:
                try:
                    old.destroy()
                except tk.TclError:
                    pass
        self._old_page = None
        f = ctk.CTkFrame(self, fg_color=self.p["bg"], corner_radius=0)
        self.page, self.page_name = f, name
        builder(f)
        f.place(relx=0 if instant else 1.0, y=0, relwidth=1, relheight=1)
        f.lift()
        if self.auth_visible:
            self.auth_frame.lift()
        if not instant:
            self.tween("page", 280, lambda t: f.place_configure(relx=1.0 - t))

    def _close_page(self):
        f = self.page
        if f is None:
            return
        self.page, self.page_name = None, None
        self.pv, self.edit = None, None
        self._old_page = f

        def done():
            try:
                f.destroy()
            except tk.TclError:
                pass
            if self._old_page is f:
                self._old_page = None

        self.tween("page", 240, lambda t: f.place_configure(relx=t), done=done)

    def _page_header(self, parent, title, back):
        p = self.p
        h = ctk.CTkFrame(parent, fg_color=p["panel"], corner_radius=0, height=HEADER_H)
        h.pack(fill="x")
        h.pack_propagate(False)
        self._icon_btn(h, "←", back, p["panel"], p["surface"], size=42, fsize=20
                       ).pack(side="left", padx=(14, 6))
        ctk.CTkLabel(h, text=title, text_color=p["text"], font=self.font(17, "bold")
                     ).pack(side="left")
        ctk.CTkFrame(h, height=1, fg_color=p["border"], corner_radius=0
                     ).place(relx=0, rely=1.0, relwidth=1, anchor="sw")

    def _scroll_page(self, parent):
        p = self.p
        sc = ctk.CTkScrollableFrame(parent, fg_color="transparent", corner_radius=0,
                                    scrollbar_button_color=p["accent_dark"],
                                    scrollbar_button_hover_color=p["accent"])
        sc.pack(fill="both", expand=True)
        return sc

    def _card(self, parent, title=None):
        p = self.p
        card = ctk.CTkFrame(parent, fg_color=p["panel"], corner_radius=18,
                            border_width=1, border_color=p["border_soft"])
        card.pack(fill="x", padx=40, pady=8)
        if title:
            ctk.CTkLabel(card, text=title.upper(), text_color=p["author"], anchor="w",
                         font=self.font(12, "bold")).pack(fill="x", padx=18, pady=(14, 2))
        return card

    def _row(self, card, label):
        p = self.p
        r = ctk.CTkFrame(card, fg_color="transparent")
        r.pack(fill="x", padx=18, pady=8)
        r.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(r, text=label, anchor="w", text_color=p["text"], font=self.font(14)
                     ).grid(row=0, column=0, sticky="w")
        return r

    def _button(self, parent, text, command, primary=False, danger=False, width=0):
        p = self.p
        color = p["err"] if danger else p["accent"]
        return ctk.CTkButton(
            parent, text=text, command=command, height=36, corner_radius=18,
            fg_color=color if primary else "transparent",
            hover_color=p["accent_hover"] if primary else p["accent_dark"],
            border_width=0 if primary else 1, border_color=color,
            text_color=p["on_accent"] if primary else (p["err"] if danger else p["text"]),
            font=self.font(13), **({"width": width} if width else {}))

    def _slider(self, parent, lo, hi, steps, value, command, width=200):
        p = self.p
        s = ctk.CTkSlider(parent, from_=lo, to=hi, number_of_steps=steps, width=width,
                          progress_color=p["accent"], button_color=p["accent"],
                          button_hover_color=p["accent_hover"], fg_color=p["accent_dark"],
                          command=command)
        s.set(value)
        return s

    def _switch(self, parent, value, key):
        p = self.p
        sw = ctk.CTkSwitch(parent, text="", width=46, progress_color=p["accent"],
                           fg_color=p["accent_dark"], button_color=p["on_accent"],
                           button_hover_color=p["on_accent_muted"])
        sw.configure(command=lambda: self._on_toggle(key, sw))
        if value:
            sw.select()
        return sw
