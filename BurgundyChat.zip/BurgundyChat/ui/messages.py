"""Дії над повідомленнями: контекстне меню, редагування, видалення."""
import sys
import time
import tkinter as tk
from tkinter import messagebox


class MessagesMixin:
    def _new_mid(self):
        """Унікальний id повідомлення: «<мій id>.<число>»; сервер перевіряє, що автор — це ви."""
        self.mid_seq = max(self.mid_seq + 1, int(time.time() * 1000))
        return f"{self.my_id}.{self.mid_seq}"

    # ------------------------------------------------------- Події бульбашки
    def _bind_bubble(self, widget, rec):
        """Права кнопка миші — меню; клік по зображенню — перегляд на весь екран."""
        right = ["<Button-3>"] + (["<Button-2>", "<Control-Button-1>"] if sys.platform == "darwin" else [])
        is_image = rec["type"] == "image"

        def walk(w):
            for seq in right:
                tk.Misc.bind(w, seq, lambda e, r=rec: self._show_msg_menu(e, r), add="+")
            if is_image:
                tk.Misc.bind(w, "<Button-1>", lambda e, r=rec: self.open_lightbox(r), add="+")
                try:
                    tk.Misc.configure(w, cursor="hand2")
                except tk.TclError:
                    pass
            for child in w.winfo_children():
                walk(child)

        walk(widget)

    def _show_msg_menu(self, event, rec):
        p = self.p
        own, kind = rec["kind"] == "own", rec["type"]
        deleted = rec.get("deleted")
        entries = []
        if kind == "text":
            entries.append(("Копіювати", lambda: self._copy_text(rec), None))
        if kind == "image":
            entries.append(("Відкрити на весь екран", lambda: self.open_lightbox(rec), None))
        if kind in ("image", "audio", "video", "file"):
            entries.append(("Зберегти як…", lambda: self._save_file(rec), None))
        if own and not deleted:
            if kind == "text":
                entries.append(("Редагувати", lambda: self._start_edit(rec), None))
            entries.append(("Видалити", lambda: self._delete_message(rec), p["err"]))
        if not entries:
            return
        menu = tk.Menu(self, tearoff=0, bg=p["panel"], fg=p["text"], bd=0, relief="flat",
                       activebackground=p["accent"], activeforeground=p["on_accent"],
                       font=("Segoe UI", 10))
        for label, cmd, color in entries:
            if label == "Видалити":
                menu.add_separator()
            menu.add_command(label=label, command=cmd, **({"foreground": color} if color else {}))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _copy_text(self, rec):
        self.clipboard_clear()
        self.clipboard_append(rec.get("text", ""))

    # ----------------------------------------------------------- Редагування
    def _start_edit(self, rec):
        if rec["kind"] != "own" or rec["type"] != "text":
            return
        self.editing = rec
        preview = rec["text"] if len(rec["text"]) <= 60 else rec["text"][:59] + "…"
        self.edit_label.configure(text="Редагування: " + preview)
        self.edit_bar.grid()
        self.message_entry.delete(0, "end")
        self.message_entry.insert(0, rec["text"])
        self.message_entry.focus_set()
        self._update_action()

    def _cancel_edit(self):
        if not self.editing:
            return
        self.editing = None
        self.edit_bar.grid_remove()
        self.message_entry.delete(0, "end")
        self._update_action()

    def _commit_edit(self, text):
        rec = self.editing
        if text == rec["text"]:
            self._cancel_edit()
            return
        if not self._send_raw(f"EDIT@{rec['mid']}@{rec['chat']}@{text}\n"):
            self.sys_msg("Помилка: немає зʼєднання з сервером")
            return
        rec["text"], rec["edited"] = text, True
        self._cancel_edit()
        self._refresh_item(rec)
        self._refresh_row(rec["chat"])

    # ------------------------------------------------------------- Видалення
    def _delete_message(self, rec):
        if not messagebox.askyesno("Видалити повідомлення",
                                   "Видалити це повідомлення в усіх учасників чату?", parent=self):
            return
        if not self._send_raw(f"DEL@{rec['mid']}@{rec['chat']}\n"):
            self.sys_msg("Помилка: немає зʼєднання з сервером")
            return
        self._remove_message(rec)

    def _find_item(self, rec):
        return next((it for it in self.items if it["rec"] is rec), None)

    def _remove_message(self, rec):
        chat = rec["chat"]
        if rec in self.chats[chat]["msgs"]:
            self.chats[chat]["msgs"].remove(rec)
        self.mid_index.pop(rec.get("mid"), None)
        if self.ui_ready and chat == self.current:
            it = self._find_item(rec)
            if it:
                sign = 1 if it["kind"] == "own" else -1

                def fn(t):
                    it["ox"] = sign * 90 * t
                    self._place(it)

                self.tween(("out", it["win"]), 200, fn, done=lambda: self._drop_item(it))
        self._refresh_row(chat)
        self._layout_chat_list()

    def _drop_item(self, it):
        if it not in self.items:
            return
        idx = self.items.index(it)
        self._destroy_item(it)
        self.items.remove(it)
        # якщо від дня лишився лише розділювач дати — прибираємо й його
        if idx > 0 and self.items[idx - 1]["rec"] is None and (
                idx >= len(self.items) or self.items[idx]["rec"] is None):
            pill = self.items.pop(idx - 1)
            self._destroy_item(pill)
        self._relayout()

    def _destroy_item(self, it):
        try:
            self.chat.delete(it["win"])
            if it.get("av"):
                self.chat.delete(it["av"])
            it["widget"].destroy()
        except tk.TclError:
            pass

    def _refresh_item(self, rec):
        """Перемальовує одну бульбашку (після редагування або позначки «видалено»)."""
        it = self._find_item(rec)
        if not it:
            return
        widget, labels = self._bubble(rec)
        self.chat.itemconfigure(it["win"], window=widget)
        try:
            it["widget"].destroy()
        except tk.TclError:
            pass
        it["widget"], it["labels"] = widget, labels
        self._bind_bubble(widget, rec)
        self._relayout()

    # ----------------------------------------------- Події від інших учасників
    def _lookup_remote(self, mid, sender):
        rec = self.mid_index.get(mid)
        return rec if rec and rec.get("author") == sender else None

    def _on_remote_edit(self, rest):
        p = rest.split("@", 3)                        # mid, автор, чат, новий текст
        if len(p) != 4:
            return
        rec = self._lookup_remote(p[0], p[1])
        if rec and rec["type"] == "text":
            rec["text"], rec["edited"] = p[3], True
            self._refresh_item(rec)
            self._refresh_row(rec["chat"])

    def _on_remote_delete(self, rest):
        p = rest.split("@", 2)                        # mid, автор, чат
        if len(p) != 3:
            return
        rec = self._lookup_remote(p[0], p[1])
        if not rec:
            return
        if self.is_admin:                             # адміністратор бачить видалене з кошиком
            rec["deleted"] = True
            self._refresh_item(rec)
        else:
            self._remove_message(rec)
