"""Спливаючі сповіщення в куті екрана."""
import ctypes
import sys
import time
import tkinter as tk

from PIL import Image
from PIL import ImageTk

from consts import GROUP, SOUND_COOLDOWN, TOAST_SECONDS, TOAST_W
from ui.helpers import _RECT, set_alpha


class NotifyMixin:
    def _notify(self, chat, sender_id, name, preview):
        if not self.cfg["notify"]:
            return
        active = self.focus_displayof() is not None and self.state() != "iconic"
        if active and chat == self.current and not self.auth_visible:
            return
        now = time.time()
        if now - self.last_sound >= SOUND_COOLDOWN:   # антиспам звуку
            self.last_sound = now
            self._play_notify_sound()
        title = name if chat != GROUP else f"{name} · загальний чат"
        self._show_toast(chat, title, preview, sender_id)

    def _scale(self):
        try:
            return float(self._get_window_scaling())
        except Exception:
            return 1.0

    def _screen_corner(self, t):
        """Права нижня точка робочої області екрана (над панеллю задач), у координатах Tk."""
        if sys.platform == "win32":
            try:
                rect = _RECT()
                if ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0):
                    return rect.right, rect.bottom
            except Exception:
                pass
        return t.winfo_screenwidth(), t.winfo_screenheight() - 40

    def _show_toast(self, chat, title, body, sender_id):
        body = body if len(body) <= 90 else body[:89] + "…"
        self.toast_chat = chat
        if self.toast is not None:
            # антиспам: оновлюємо наявне вікно, а не плодимо нові
            self.toast_count += 1
            self.toast_widgets["title"].configure(text=f"Нові повідомлення ({self.toast_count})")
            self.toast_widgets["body"].configure(text=f"{title}: {body}"[:110])
            self._place_toast(animate=False)
            self._restart_toast_timer()
            return
        p, sc = self.p, self._scale()
        self.toast_count = 1
        t = tk.Toplevel(self)
        t.overrideredirect(True)
        t.attributes("-topmost", True)
        t.configure(bg=p["accent"])
        inner = tk.Frame(t, bg=p["panel"])
        inner.pack(fill="both", expand=True, padx=1, pady=1)

        pil = self.avatar_pil(sender_id or GROUP, int(44 * sc))
        bg = Image.new("RGBA", pil.size, p["panel"])
        photo = ImageTk.PhotoImage(Image.alpha_composite(bg, pil))
        lab = tk.Label(inner, image=photo, bg=p["panel"], bd=0)
        lab.image = photo
        lab.pack(side="left", padx=(12, 0), pady=10)
        box = tk.Frame(inner, bg=p["panel"])
        box.pack(side="left", fill="both", expand=True, padx=12, pady=10)
        tl = tk.Label(box, text=title, bg=p["panel"], fg=p["author"], anchor="w",
                      font=("Segoe UI", 10, "bold"))
        tl.pack(fill="x")
        bl = tk.Label(box, text=body, bg=p["panel"], fg=p["text"], anchor="w", justify="left",
                      wraplength=int((TOAST_W - 90) * sc), font=("Segoe UI", 10))
        bl.pack(fill="x")
        for w in (t, inner, lab, box, tl, bl):
            w.bind("<Button-1>", lambda e: self._open_from_toast())
        self.toast = t
        self.toast_widgets = {"title": tl, "body": bl}
        set_alpha(t, 0.0)
        self._place_toast(animate=True)
        self._restart_toast_timer()

    def _place_toast(self, animate=False):
        t = self.toast
        if t is None:
            return
        sc = self._scale()
        t.update_idletasks()
        w, h = int(TOAST_W * sc), t.winfo_reqheight()
        right, bottom = self._screen_corner(t)
        x, y = right - w - int(14 * sc), bottom - h - int(14 * sc)
        if not animate:
            t.geometry(f"{w}x{h}+{x}+{y}")
            return
        off = int(70 * sc)

        def fn(k):
            t.geometry(f"{w}x{h}+{x + int(off * (1 - k))}+{y}")
            set_alpha(t, 0.98 * k)

        self.tween("toast", 240, fn)

    def _restart_toast_timer(self):
        if self.toast_job:
            self.after_cancel(self.toast_job)
        self.toast_job = self.after(TOAST_SECONDS * 1000, self._close_toast)

    def _close_toast(self, now=False):
        if self.toast_job:
            self.after_cancel(self.toast_job)
            self.toast_job = None
        t, self.toast = self.toast, None
        if t is None:
            return

        def kill():
            try:
                t.destroy()
            except tk.TclError:
                pass

        if now:
            self._tweens.pop("toast", None)
            kill()
            return

        def fn(k):
            set_alpha(t, 0.98 * (1 - k))

        self.tween("toast", 200, fn, done=kill)

    def _open_from_toast(self):
        chat = self.toast_chat
        self._close_toast(now=True)
        self.deiconify()
        self.lift()
        self.attributes("-topmost", True)
        self.after_idle(lambda: self.attributes("-topmost", False))
        self.focus_force()
        if not self.auth_visible and chat in self.chats:
            self.switch_chat(chat)
