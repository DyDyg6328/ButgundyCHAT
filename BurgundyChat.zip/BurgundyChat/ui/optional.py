"""Необовʼязкові бібліотеки: без них чат працює, але без запису голосових і звуку."""
import os

try:
    import numpy as np
    import sounddevice as sd
except (ImportError, OSError):  # OSError — коли в системі немає PortAudio
    np = sd = None

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
try:
    import pygame
except (ImportError, OSError):
    pygame = None
