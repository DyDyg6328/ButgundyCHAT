"""Перегляд зображень на весь екран."""
import io
import tkinter as tk

from PIL import Image, ImageTk

from ui.helpers import set_alpha


class LightboxMixin:
    def open_lightbox(self, rec):
        recs = [it["rec"] for it in self.items if it["rec"] and it["rec"]["type"] == "image"]
        if rec not in recs:
            recs = [rec]
        self._close_lightbox(now=True)
        win = tk.Toplevel(self)
        win.configure(bg="#000000")
        win.attributes("-fullscreen", True)
        win.update_idletasks()
        if win.winfo_width() < 300:                   # менеджер вікон не розгорнув — робимо самі
            win.geometry(f"{win.winfo_screenwidth()}x{win.winfo_screenheight()}+0+0")
        cv = tk.Canvas(win, bg="#000000", highlightthickness=0, bd=0)
        cv.pack(fill="both", expand=True)
        self.lightbox = {"win": win, "cv": cv, "recs": recs, "idx": recs.index(rec), "photo": None}
        cv.bind("<Button-1>", self._lb_click)
        for key, step in (("<Escape>", None), ("<Left>", -1), ("<Right>", 1)):
            win.bind(key, lambda e, s=step: self._close_lightbox() if s is None else self._lb_step(s))
        win.focus_force()
        set_alpha(win, 0.0)
        win.after(80, self._lb_render)
        self.tween("lightbox", 220, lambda t: set_alpha(win, t))

    def _lb_render(self):
        lb = self.lightbox
        if not lb:
            return
        cv, rec = lb["cv"], lb["recs"][lb["idx"]]
        w, h = max(cv.winfo_width(), 200), max(cv.winfo_height(), 200)
        cv.delete("all")
        try:
            img = Image.open(io.BytesIO(rec["raw"])).convert("RGB")
        except Exception:
            self._close_lightbox()
            return
        scale = min(w * 0.94 / img.width, h * 0.88 / img.height, 2.0)
        size = (max(1, int(img.width * scale)), max(1, int(img.height * scale)))
        lb["photo"] = ImageTk.PhotoImage(img.resize(size, Image.LANCZOS))
        cv.create_image(w // 2, h // 2, image=lb["photo"], tags=("img",))
        total = len(lb["recs"])
        cv.create_text(24, 28, anchor="w", fill="#cfcfcf", font=("Segoe UI", 12),
                       text=f"{rec.get('name', '')}   {lb['idx'] + 1} / {total}")
        cv.create_text(w - 28, 28, anchor="e", fill="#ffffff", font=("Segoe UI", 20, "bold"),
                       text="✕", tags=("ui", "close"))
        cv.create_text(w - 78, 28, anchor="e", fill="#ffffff", font=("Segoe UI", 12),
                       text="⬇ Зберегти", tags=("ui", "save"))
        if total > 1:
            cv.create_text(36, h // 2, fill="#ffffff", font=("Segoe UI", 40), text="‹",
                           tags=("ui", "prev"))
            cv.create_text(w - 36, h // 2, fill="#ffffff", font=("Segoe UI", 40), text="›",
                           tags=("ui", "next"))
        cv.create_text(w // 2, h - 20, fill="#777777", font=("Segoe UI", 10),
                       text="Esc — закрити   ←  → — наступне зображення")

    def _lb_click(self, event):
        lb = self.lightbox
        if not lb:
            return
        tags = lb["cv"].gettags("current")
        if "close" in tags:
            self._close_lightbox()
        elif "save" in tags:
            self._save_file(lb["recs"][lb["idx"]])
        elif "prev" in tags:
            self._lb_step(-1)
        elif "next" in tags:
            self._lb_step(1)
        elif "img" not in tags:                       # клік повз зображення — закрити
            self._close_lightbox()

    def _lb_step(self, step):
        lb = self.lightbox
        if lb:
            lb["idx"] = max(0, min(len(lb["recs"]) - 1, lb["idx"] + step))
            self._lb_render()

    def _close_lightbox(self, now=False):
        lb, self.lightbox = self.lightbox, None
        if not lb:
            return
        try:
            lb["win"].destroy()
        except tk.TclError:
            pass
        self.focus_force()
