"""Профіль: перегляд, редагування, аватар, банер, пісня."""
from tkinter import filedialog
import base64
import io
import json
import os
import theme
import threading

from PIL import Image
from PIL import ImageOps
import customtkinter as ctk

from consts import GROUP, KEEP, PROFILE_W


class ProfileMixin:
    def _profile_request(self, uid):
        self._send_raw(f"PROFILE_GET@{uid}\n")

    def open_profile_view(self, uid, instant=False):
        if not uid or uid == GROUP:
            return
        self.pv = {"uid": uid}
        self._open_page("profile_view", lambda f: self._build_profile_view(f, uid), instant)
        self._profile_request(uid)

    def _build_profile_view(self, f, uid):
        p = self.p
        self._page_header(f, "Профіль", self._close_page)
        sc = self._scroll_page(f)
        card = ctk.CTkFrame(sc, fg_color=p["panel"], corner_radius=20, border_width=1,
                            border_color=p["border_soft"])
        card.pack(pady=24)
        head = ctk.CTkLabel(card, text="", width=PROFILE_W)
        head.pack()
        name = ctk.CTkLabel(card, text="", anchor="w", text_color=p["text"],
                            font=self.font(22, "bold"), width=PROFILE_W - 48)
        name.pack(padx=24, pady=(4, 0))
        status = ctk.CTkLabel(card, text="", anchor="w", text_color=p["muted"],
                              font=self.font(13), width=PROFILE_W - 48)
        status.pack(padx=24)
        bio = ctk.CTkLabel(card, text="", anchor="w", justify="left", text_color=p["text"],
                           font=self.font(14), wraplength=PROFILE_W - 48, width=PROFILE_W - 48)
        bio.pack(padx=24, pady=(12, 0))
        song = ctk.CTkFrame(card, fg_color=p["surface"], corner_radius=16)
        song_btn = ctk.CTkButton(song, text="▶", width=40, height=40, corner_radius=20,
                                 fg_color=p["accent"], hover_color=p["accent_hover"],
                                 text_color=p["on_accent"], font=self.font(14))
        song_btn.pack(side="left", padx=(10, 8), pady=10)
        song_lbl = ctk.CTkLabel(song, text="", anchor="w", text_color=p["text"],
                                font=self.font(13, "bold"))
        song_lbl.pack(side="left", padx=(0, 16))
        action = ctk.CTkButton(card, text="", height=40, corner_radius=20, fg_color=p["accent"],
                               hover_color=p["accent_hover"], text_color=p["on_accent"],
                               font=self.font(14, "bold"))
        action.pack(padx=24, pady=(18, 24), fill="x")
        self.pv = {"uid": uid, "head": head, "name": name, "status": status, "bio": bio,
                   "song": song, "song_btn": song_btn, "song_lbl": song_lbl, "action": action}
        self._fill_profile_view()

    def _fill_profile_view(self):
        pv = self.pv
        if not pv or "head" not in pv:
            return
        uid, p = pv["uid"], self.p
        prof = self.profiles.get(uid, {})
        av = self.avatar_pil(uid, 192).resize((96, 96), Image.LANCZOS)
        hdr = theme.profile_header(prof.get("banner"), av, PROFILE_W, 180, 96, p["panel"],
                                   p["accent_dark"], p["accent"])
        pv["head"].configure(image=self._ctk_image(hdr))
        pv["name"].configure(text=self._name_of(uid))
        if uid == self.my_id:
            st = "це ви"
        else:
            st = "в мережі" if uid in self.online else "не в мережі"
        pv["status"].configure(text=st)
        pv["bio"].configure(text=prof.get("bio") or "Інформації про себе поки немає")
        if prof.get("has_song"):
            pv["song_lbl"].configure(text="🎵  " + (prof.get("song_name") or "Пісня профілю"))
            pv["song_btn"].configure(command=lambda: self._play_profile_song(uid))
            pv["song"].pack(padx=24, pady=(14, 0), anchor="w", before=pv["action"])
        else:
            pv["song"].pack_forget()
        if uid == self.my_id:
            pv["action"].configure(text="Редагувати профіль", command=self.open_profile_edit)
        else:
            pv["action"].configure(
                text="Написати повідомлення",
                command=lambda: (self._close_page(), self.switch_chat(uid)))
        self._attach_player(f"song{uid}", pv["song_btn"], None)

    def _play_profile_song(self, uid):
        if self.player and self.player["pid"] == f"song{uid}":
            self._stop_player()
            return
        have = self.songs.get(uid)
        if have:
            self._play(f"song{uid}", "music", have[1], self.pv["song_btn"] if self.pv else None)
        else:
            self.want_song = uid
            self._send_raw(f"SONG_GET@{uid}\n")

    def open_profile_edit(self, instant=False):
        if not self.my_id:
            return
        prof = self.profiles.get(self.my_id, {})
        self.edit = {"avatar": KEEP, "banner": KEEP, "song": KEEP, "song_name": "",
                     "has_song": bool(prof.get("has_song")),
                     "old_song_name": prof.get("song_name", "")}
        self._open_page("profile_edit", self._build_profile_edit, instant)
        self._profile_request(self.my_id)

    def _build_profile_edit(self, f):
        p = self.p
        self._page_header(f, "Мій профіль", self._close_page)
        sc = self._scroll_page(f)
        card = ctk.CTkFrame(sc, fg_color=p["panel"], corner_radius=20, border_width=1,
                            border_color=p["border_soft"])
        card.pack(pady=24)
        ed = self.edit
        ed["head"] = ctk.CTkLabel(card, text="", width=PROFILE_W)
        ed["head"].pack()
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=(6, 0))
        for text, cmd in (("Змінити банер", self._pick_banner),
                          ("Прибрати банер", self._clear_banner),
                          ("Змінити фото", self._pick_avatar),
                          ("Прибрати фото", self._clear_avatar)):
            self._button(row, text, cmd).pack(side="left", padx=(0, 6))

        def label(t):
            ctk.CTkLabel(card, text=t, anchor="w", text_color=p["muted"], font=self.font(12)
                         ).pack(fill="x", padx=24, pady=(14, 2))

        label("Імʼя")
        ed["name"] = ctk.CTkEntry(card, height=40, corner_radius=12, fg_color=p["surface"],
                                  border_color=p["border_soft"], text_color=p["text"],
                                  width=PROFILE_W - 48)
        ed["name"].pack(padx=24)
        ed["name"].insert(0, self.username)
        label("Про себе (до 300 символів)")
        ed["bio"] = ctk.CTkTextbox(card, height=90, corner_radius=12, fg_color=p["surface"],
                                   border_color=p["border_soft"], border_width=1,
                                   text_color=p["text"], width=PROFILE_W - 48,
                                   font=self.font(14))
        ed["bio"].pack(padx=24)
        ed["bio"].insert("1.0", self.profiles.get(self.my_id, {}).get("bio", ""))
        label("Пісня в профілі (mp3)")
        srow = ctk.CTkFrame(card, fg_color="transparent")
        srow.pack(fill="x", padx=24)
        ed["song_lbl"] = ctk.CTkLabel(srow, text="", anchor="w", text_color=p["text"],
                                      font=self.font(13))
        ed["song_lbl"].pack(side="left", padx=(0, 10))
        self._button(srow, "Обрати mp3…", self._pick_song).pack(side="left", padx=(0, 6))
        self._button(srow, "Прибрати", self._clear_song).pack(side="left", padx=(0, 6))
        ed["preview"] = self._button(srow, "▶", self._preview_song, width=40)
        ed["preview"].pack(side="left")
        ed["status"] = ctk.CTkLabel(card, text="", anchor="w", text_color=p["muted"],
                                    font=self.font(12))
        ed["status"].pack(fill="x", padx=24, pady=(14, 0))
        self._button(card, "Зберегти профіль", self._save_profile, primary=True
                     ).pack(padx=24, pady=(6, 24), fill="x")
        self._refresh_edit_preview()

    def _edit_current_images(self):
        ed = self.edit
        prof = self.profiles.get(self.my_id, {})
        avatar = prof.get("avatar") if ed["avatar"] is KEEP else ed["avatar"]
        banner = prof.get("banner") if ed["banner"] is KEEP else ed["banner"]
        return avatar, banner

    def _refresh_edit_preview(self):
        ed = self.edit
        if not ed or "head" not in ed:
            return
        p = self.p
        avatar, banner = self._edit_current_images()
        av = theme.avatar_image(96, name=self.username, picture=avatar, accent=self.cfg["accent"])
        hdr = theme.profile_header(banner, av, PROFILE_W, 150, 96, p["panel"],
                                   p["accent_dark"], p["accent"])
        ed["head"].configure(image=self._ctk_image(hdr))
        if ed["song"] is KEEP:
            name = ed["old_song_name"] if ed["has_song"] else ""
        else:
            name = ed["song_name"] if ed["song"] else ""
        ed["song_lbl"].configure(text="🎵 " + name if name else "Пісню не обрано")

    def _load_pil(self, title):
        path = filedialog.askopenfilename(
            title=title, filetypes=[("Зображення", "*.png *.jpg *.jpeg *.bmp *.webp *.gif")])
        if not path:
            return None
        try:
            return Image.open(path).convert("RGB")
        except Exception as e:
            self.sys_msg(f"Не вдалося відкрити зображення: {e}")
            return None

    def _pick_avatar(self):
        img = self._load_pil("Оберіть фото профілю")
        if img is not None:
            self.edit["avatar"] = ImageOps.fit(img, (192, 192), Image.LANCZOS)
            self._refresh_edit_preview()

    def _clear_avatar(self):
        self.edit["avatar"] = None
        self._refresh_edit_preview()

    def _pick_banner(self):
        img = self._load_pil("Оберіть банер профілю")
        if img is not None:
            self.edit["banner"] = ImageOps.fit(img, (900, 300), Image.LANCZOS)
            self._refresh_edit_preview()

    def _clear_banner(self):
        self.edit["banner"] = None
        self._refresh_edit_preview()

    def _pick_song(self):
        path = filedialog.askopenfilename(title="Оберіть пісню", filetypes=[("MP3", "*.mp3")])
        if not path:
            return
        try:
            if os.path.getsize(path) > 10 * 1024 * 1024:
                self.edit["status"].configure(text="Пісня завелика: максимум 10 МБ",
                                              text_color=self.p["err"])
                return
            with open(path, "rb") as fh:
                self.edit["song"] = fh.read()
        except OSError as e:
            self.edit["status"].configure(text=f"Помилка: {e}", text_color=self.p["err"])
            return
        self.edit["song_name"] = os.path.splitext(os.path.basename(path))[0][:80]
        self._refresh_edit_preview()

    def _clear_song(self):
        self.edit["song"] = None
        self.edit["song_name"] = ""
        self._refresh_edit_preview()

    def _preview_song(self):
        ed = self.edit
        raw = None
        if ed["song"] is KEEP:
            if ed["has_song"]:
                have = self.songs.get(self.my_id)
                if have:
                    raw = have[1]
                else:
                    self.want_song = self.my_id
                    self._send_raw(f"SONG_GET@{self.my_id}\n")
                    return
        elif ed["song"]:
            raw = ed["song"]
        if raw:
            self._play("song-preview", "music", raw, ed["preview"])

    def _save_profile(self):
        ed = self.edit
        if not ed or not self.sock:
            self.sys_msg("Немає зʼєднання з сервером")
            return
        new_name = " ".join(ed["name"].get().replace("@", "").split())
        payload = {"bio": ed["bio"].get("1.0", "end-1c").strip()[:300]}

        def jpeg(img, q):
            buf = io.BytesIO()
            img.convert("RGB").save(buf, format="JPEG", quality=q)
            return base64.b64encode(buf.getvalue()).decode("ascii")

        if ed["avatar"] is not KEEP:
            payload["avatar"] = jpeg(ed["avatar"], 88) if ed["avatar"] is not None else ""
        if ed["banner"] is not KEEP:
            payload["banner"] = jpeg(ed["banner"], 85) if ed["banner"] is not None else ""
        if ed["song"] is not KEEP:
            payload["song"] = base64.b64encode(ed["song"]).decode("ascii") if ed["song"] else ""
            payload["song_name"] = ed["song_name"]
        ed["status"].configure(text="Збереження…", text_color=self.p["muted"])
        if new_name and new_name != self.username:
            self._send_raw(f"RENAME@{new_name}\n")
        line = "PROFILE_SET@" + json.dumps(payload) + "\n"

        def work():
            if not self._send_raw(line):
                self.incoming.put(("system", "Не вдалося зберегти профіль: немає зʼєднання"))

        threading.Thread(target=work, daemon=True).start()
