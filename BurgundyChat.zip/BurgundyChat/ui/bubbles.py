"""Бульбашки повідомлень: текст, зображення, аудіо, файли."""
from tkinter import filedialog
import datetime
import io
import os
import re
import theme
from theme import mix

from PIL import Image
import customtkinter as ctk

from consts import GROUP
from ui.helpers import open_external


class BubblesMixin:
    def _bubble(self, rec):
        p = self.p
        own = rec["kind"] == "own"
        fs = self.cfg["font_size"]
        fg = p["out_bubble"] if own else p["in_bubble"]
        tc = p["on_accent"] if own else p["text"]
        mc = p["on_accent_muted"] if own else p["muted"]
        deleted = rec.get("deleted")
        if deleted:                       # видалене повідомлення (бачить лише адміністратор)
            tc = mix(tc, fg, 0.45)
        wrap = self._wrap()
        b = ctk.CTkFrame(self.chat, corner_radius=16, fg_color=fg,
                         border_width=0 if own else 1, border_color=p["border_soft"])
        labels = []
        if deleted:
            strip = ctk.CTkFrame(b, fg_color="transparent", height=20)
            strip.pack(fill="x", padx=8, pady=(6, 0))
            ctk.CTkLabel(strip, text="", image=self._trash_image(), width=18, height=18
                         ).pack(side="right")
        if not own and rec["chat"] == GROUP:
            ctk.CTkLabel(b, text=self.users.get(rec.get("author"), "?"), text_color=p["author"],
                         font=self.font(fs - 1, "bold")).pack(anchor="w", padx=12, pady=(8, 0))
        t = rec["type"]
        if t == "text":
            lbl = ctk.CTkLabel(b, text=rec["text"], text_color=tc, justify="left",
                               wraplength=wrap, font=self.font(fs))
            lbl.pack(anchor="w", padx=12, pady=(7, 0))
            labels.append(lbl)
        elif t == "image":
            img = rec.get("_img")
            if img is None:
                pil = Image.open(io.BytesIO(rec["raw"])).convert("RGBA")
                pil.thumbnail((300, 300))
                img = rec["_img"] = self._ctk_image(pil)
            ctk.CTkLabel(b, text="", image=img).pack(padx=8, pady=(8, 0))
        elif t in ("voice", "audio"):
            self._audio_row(b, rec, own, tc, mc)
        else:
            self._file_row(b, rec, own, tc, mc)
        stamp = datetime.datetime.fromtimestamp(rec["ts"]).strftime("%H:%M")
        if rec.get("edited"):
            stamp = "змінено · " + stamp
        ctk.CTkLabel(b, text=stamp, text_color=mc, font=self.font(10)
                     ).pack(anchor="e", padx=10, pady=(0, 5))
        return b, labels

    def _trash_image(self):
        img = self._img_cache.get("trash")
        if img is None:
            img = self._img_cache["trash"] = self._ctk_image(
                theme.trash_icon(36, self.p["err"]), (18, 18))
        return img

    def _audio_row(self, b, rec, own, tc, mc):
        p = self.p
        row = ctk.CTkFrame(b, fg_color="transparent")
        row.pack(padx=10, pady=(8, 0), anchor="w")
        pid = f"m{rec['id']}"
        btn = ctk.CTkButton(
            row, text="▶", width=40, height=40, corner_radius=20,
            fg_color=p["on_accent"] if own else p["accent"],
            hover_color=p["on_accent_muted"] if own else p["accent_hover"],
            text_color=p["accent"] if own else p["on_accent"], font=self.font(14))
        btn.grid(row=0, column=0, rowspan=2, padx=(0, 10))
        if rec["type"] == "voice":
            title, kind, ext = "Голосове повідомлення", "voice", ".wav"
        else:
            name = rec.get("name", "audio.mp3")
            title = name if len(name) <= 26 else name[:25] + "…"
            kind, ext = "music", ".mp3"
        ctk.CTkLabel(row, text=title, text_color=tc, anchor="w",
                     font=self.font(13, "bold")).grid(row=0, column=1, sticky="w")
        bar = ctk.CTkProgressBar(row, width=150, height=6,
                                 progress_color=p["on_accent"] if own else p["accent"],
                                 fg_color=p["track_out"] if own else p["track_in"])
        bar.set(0)
        bar.grid(row=1, column=1, sticky="w", pady=(2, 0))
        info = (self._fmt_dur(rec["dur"]) if rec.get("dur") else
                theme.fmt_size(rec.get("size", len(rec["raw"]))))
        ctk.CTkLabel(row, text=info, text_color=mc, font=self.font(11)
                     ).grid(row=1, column=2, sticky="w", padx=(10, 0))
        btn.configure(command=lambda: self._play(pid, kind, rec["raw"], btn, bar, ext))
        if rec["type"] == "audio":
            ctk.CTkButton(row, text="⬇", width=30, height=30, corner_radius=15,
                          fg_color="transparent", hover_color=p["accent_dark"], text_color=tc,
                          font=self.font(14), command=lambda: self._save_file(rec)
                          ).grid(row=0, column=2, sticky="e", padx=(10, 0))
        self._attach_player(pid, btn, bar)

    def _file_row(self, b, rec, own, tc, mc):
        p = self.p
        row = ctk.CTkFrame(b, fg_color="transparent")
        row.pack(padx=10, pady=(8, 0), anchor="w")
        icon = "🎬" if rec["type"] == "video" else "📎"
        ctk.CTkLabel(row, text=icon, width=44, height=44, corner_radius=22,
                     fg_color=p["on_accent"] if own else p["accent"],
                     text_color=p["accent"] if own else p["on_accent"], font=self.font(18)
                     ).grid(row=0, column=0, rowspan=2, padx=(0, 10))
        name = rec.get("name", "file")
        ctk.CTkLabel(row, text=name if len(name) <= 26 else name[:25] + "…", text_color=tc,
                     anchor="w", font=self.font(13, "bold")).grid(row=0, column=1, sticky="w")
        ctk.CTkLabel(row, text=theme.fmt_size(rec.get("size", len(rec["raw"]))), text_color=mc,
                     anchor="w", font=self.font(11)).grid(row=1, column=1, sticky="w")
        for col, (txt, cmd) in enumerate((("Відкрити", lambda: self._open_file(rec)),
                                          ("⬇", lambda: self._save_file(rec))), start=2):
            ctk.CTkButton(row, text=txt, width=78 if col == 2 else 30, height=30,
                          corner_radius=15, fg_color="transparent", border_width=1,
                          border_color=tc, hover_color=p["accent_dark"], text_color=tc,
                          font=self.font(12), command=cmd
                          ).grid(row=0, column=col, rowspan=2, padx=(8 if col == 2 else 4, 0))

    @staticmethod
    def _fmt_dur(sec):
        sec = int(round(float(sec)))
        return f"{sec // 60}:{sec % 60:02d}"

    def _temp_file(self, rec):
        path = rec.get("_path")
        if not path or not os.path.isfile(path):
            safe = re.sub(r"[^\w.\-]", "_", rec.get("name", "file"))
            path = os.path.join(self.tmpdir, f"{rec['id']}_{safe}")
            with open(path, "wb") as f:
                f.write(rec["raw"])
            rec["_path"] = path
        return path

    def _open_file(self, rec):
        open_external(self._temp_file(rec))

    def _save_file(self, rec):
        name = rec.get("name", "file")
        dest = filedialog.asksaveasfilename(initialfile=name,
                                            defaultextension=os.path.splitext(name)[1])
        if dest:
            try:
                with open(dest, "wb") as f:
                    f.write(rec["raw"])
            except OSError as e:
                self.sys_msg(f"Не вдалося зберегти файл: {e}")
