"""Екран входу і реєстрації, вихід з акаунта."""
import json
import theme
import tkinter as tk

from PIL import ImageTk
import customtkinter as ctk

from consts import DEFAULT_HOST, DEFAULT_PORT, GROUP, NAME_RE


class AuthMixin:
    def _auth_entry(self, parent, placeholder, show=None):
        p = self.p
        e = ctk.CTkEntry(parent, placeholder_text=placeholder, width=280, height=40,
                         corner_radius=12, fg_color=p["surface"], border_color=p["border_soft"],
                         text_color=p["text"], placeholder_text_color=p["muted"], show=show)
        e.pack(pady=4)
        return e

    def _auth_button(self, parent, text, command):
        p = self.p
        b = ctk.CTkButton(parent, text=text, width=280, height=40, corner_radius=20,
                          fg_color=p["accent"], hover_color=p["accent"], text_color=p["on_accent"],
                          font=self.font(14, "bold"), command=command)
        self._fx(b, p["accent"], p["accent_hover"])
        b.pack(pady=(12, 0))
        return b

    def _build_auth(self):
        p = self.p
        self.auth_frame = ctk.CTkFrame(self, fg_color=p["bg"], corner_radius=0)
        self.auth_frame.place(x=0, y=0, relwidth=1, relheight=1)
        pat = theme.pattern_image(1920, 1080, self.cfg["mode"], self.cfg["accent"])
        self._auth_bg = ImageTk.PhotoImage(pat)
        tk.Label(self.auth_frame, image=self._auth_bg, bd=0).place(x=0, y=0)
        self.auth_card = ctk.CTkFrame(self.auth_frame, fg_color=p["panel"], corner_radius=22,
                                      border_width=1, border_color=p["border"])
        self.auth_card.place(relx=0.5, rely=0.5, anchor="center")
        card = self.auth_card
        ctk.CTkLabel(card, text="Burgundy Chat", text_color=p["text"],
                     font=self.font(22, "bold")).pack(pady=(24, 2), padx=34)
        ctk.CTkLabel(card, text="Спілкуйтесь у своєму стилі", text_color=p["muted"],
                     font=self.font(12)).pack(pady=(0, 14))
        self.auth_tabs = ctk.CTkSegmentedButton(
            card, values=["Вхід", "Реєстрація"], command=self._on_auth_tab, width=280,
            selected_color=p["accent"], selected_hover_color=p["accent_hover"],
            unselected_color=p["surface"], unselected_hover_color=p["accent_dark"],
            text_color=p["text"], fg_color=p["surface"], dynamic_resizing=False)
        self.auth_tabs.pack(pady=(0, 10))
        body = ctk.CTkFrame(card, fg_color="transparent")
        body.pack(padx=34)

        self.login_form = ctk.CTkFrame(body, fg_color="transparent")
        self.login_id = self._auth_entry(self.login_form, "Імʼя користувача")
        self.login_pw = self._auth_entry(self.login_form, "Пароль", show="•")
        self._auth_button(self.login_form, "Увійти", self.do_login)
        self.login_pw.bind("<Return>", lambda e: self.do_login())
        self.login_id.bind("<Return>", lambda e: self.login_pw.focus_set())
        if self.cfg["last_login"]:
            self.login_id.insert(0, self.cfg["last_login"])

        self.reg_form = ctk.CTkFrame(body, fg_color="transparent")
        self.reg_name = self._auth_entry(self.reg_form, "Імʼя користувача")
        self.reg_pw = self._auth_entry(self.reg_form, "Пароль (мін. 6 символів)", show="•")
        self.reg_pw2 = self._auth_entry(self.reg_form, "Повторіть пароль", show="•")
        self._auth_button(self.reg_form, "Зареєструватися", self.do_register)
        self.reg_pw2.bind("<Return>", lambda e: self.do_register())

        srv = ctk.CTkFrame(card, fg_color="transparent")
        srv.pack(padx=34, pady=(14, 0), fill="x")
        ctk.CTkLabel(srv, text="Сервер", text_color=p["muted"], font=self.font(12)).pack(side="left")
        self.server_entry = ctk.CTkEntry(
            srv, width=190, height=30, corner_radius=10, fg_color=p["surface"],
            border_color=p["border_soft"], text_color=p["text"], font=self.font(12))
        self.server_entry.pack(side="right")
        self.server_entry.insert(0, f"{self.cfg['server_host']}:{self.cfg['server_port']}")

        self.auth_msg = ctk.CTkLabel(card, text="", text_color=p["err"], wraplength=280,
                                     font=self.font(12), justify="center")
        self.auth_msg.pack(padx=34, pady=(10, 22))
        self._show_auth_form("login")
        if self.auth_visible:
            self._animate_auth_in()
        else:
            self.auth_frame.place_forget()

    def _animate_auth_in(self):
        self.tween("auth", 380, lambda t: self.auth_card.place_configure(rely=0.56 - 0.06 * t))

    def _on_auth_tab(self, value):
        self._show_auth_form("login" if value == "Вхід" else "reg")

    def _show_auth_form(self, name):
        for f in (self.login_form, self.reg_form):
            f.pack_forget()
        {"login": self.login_form, "reg": self.reg_form}[name].pack()
        self.auth_tabs.set("Вхід" if name == "login" else "Реєстрація")
        self._auth_info("")
        {"login": self.login_id, "reg": self.reg_name}[name].focus_set()

    def _auth_error(self, text):
        self.auth_msg.configure(text=text, text_color=self.p["err"])

    def _auth_info(self, text):
        self.auth_msg.configure(text=text, text_color=self.p["muted"])

    def _show_auth(self, form="login"):
        self.auth_visible = True
        self.auth_frame.place(x=0, y=0, relwidth=1, relheight=1)
        self.auth_frame.lift()
        self._show_auth_form(form)
        self._animate_auth_in()

    def _hide_auth(self):
        self.auth_visible = False
        self.auth_frame.place_forget()
        for e in (self.login_pw, self.reg_pw, self.reg_pw2):
            e.delete(0, "end")
        self.message_entry.focus_set()

    def _apply_server_field(self):
        """Читає адресу сервера з поля; якщо вона змінилась — запамʼятовує й розриває зʼєднання."""
        text = self.server_entry.get().strip() or f"{DEFAULT_HOST}:{DEFAULT_PORT}"
        host, sep, port = text.rpartition(":")
        if not sep:
            host, port = text, str(DEFAULT_PORT)
        if not host.strip() or not port.isdigit() or not 0 < int(port) < 65536:
            self._auth_error("Адреса сервера має вигляд хост:порт, наприклад 192.168.0.5:8080")
            return False
        host, port = host.strip(), int(port)
        if (host, port) != (self.cfg["server_host"], self.cfg["server_port"]):
            self.cfg["server_host"], self.cfg["server_port"] = host, port
            self._save_cfg()
            self._close_socket()
        return True

    def _auth_send(self, line):
        if not self._apply_server_field():
            return
        self._auth_info("")
        if self.sock and self._send_raw(line + "\n"):
            return
        self._auth_info("Підключення до сервера…")
        self.connect_to_server(first_line=line, autostart=True)

    def do_login(self):
        login, password = self.login_id.get().strip(), self.login_pw.get()
        if not login or not password:
            self._auth_error("Введіть імʼя і пароль")
            return
        self.pending_cred = (login, password)
        self._auth_send("LOGIN@" + json.dumps({"login": login, "password": password}))

    def do_register(self):
        name = " ".join(self.reg_name.get().split())
        pw, pw2 = self.reg_pw.get(), self.reg_pw2.get()
        if not NAME_RE.match(name) or not any(ch.isalnum() for ch in name):
            self._auth_error("Імʼя: 3–24 символи (літери, цифри, пробіл, . _ -)")
            return
        if len(pw) < 6:
            self._auth_error("Пароль має містити щонайменше 6 символів")
            return
        if pw != pw2:
            self._auth_error("Паролі не збігаються")
            return
        self.pending_cred = (name, pw)
        self._auth_send("REGISTER@" + json.dumps({"username": name, "password": pw}))

    def logout(self):
        self.login_line = None
        self.pending_cred = None
        self._close_socket()
        self._close_toast(now=True)
        self._close_menu()
        if self.recording:
            self._stop_record(send=False)
        self._stop_player()
        for old in (self.page, self._old_page):
            if old is not None:
                try:
                    old.destroy()
                except tk.TclError:
                    pass
        self.page = self.page_name = self._old_page = None
        self.pv = self.edit = None
        self._clear_items()
        for r in self.chat_rows.values():
            r["row"].destroy()
        self.chat_rows = {}
        self.chats = {GROUP: {"msgs": [], "unread": 0}}
        self.current = GROUP
        self.users, self.online = {}, set()
        self.avatars, self.avatar_have, self.avatar_wait = {}, {}, {}
        self.profiles, self.songs = {}, {}
        self.my_id, self.username, self.is_admin = None, "", False
        self.mid_index = {}
        self._cancel_edit()
        self._close_lightbox(now=True)
        self._build_chat_row(GROUP)
        self._layout_chat_list()
        self._update_header()
        self._set_status(False)
        self.chat.configure(scrollregion=(0, 0, 1, 1))
        self.login_pw.delete(0, "end")
        self._show_auth("login")
