"""Сторінка налаштувань: тема, колір, фон, звук."""
from tkinter import colorchooser
from tkinter import filedialog
import storage
import theme

import customtkinter as ctk

from consts import DEFAULT_SOUND
from ui.helpers import set_alpha


class SettingsMixin:
    def open_settings(self, instant=False):
        self._open_page("settings", self._build_settings, instant)

    def _build_settings(self, f):
        p, cfg = self.p, self.cfg
        self._page_header(f, "Налаштування", self._close_page)
        sc = self._scroll_page(f)

        card = self._card(sc, "Вигляд")
        r = self._row(card, "Тема")
        seg = ctk.CTkSegmentedButton(
            r, values=["Темна", "Світла"], command=self._on_mode, width=200,
            selected_color=p["accent"], selected_hover_color=p["accent_hover"],
            unselected_color=p["surface"], unselected_hover_color=p["accent_dark"],
            text_color=p["text"], fg_color=p["surface"], dynamic_resizing=False)
        seg.set("Темна" if cfg["mode"] == "dark" else "Світла")
        seg.grid(row=0, column=1)

        r = self._row(card, "Колір теми")
        sw_row = ctk.CTkFrame(r, fg_color="transparent")
        sw_row.grid(row=0, column=1)
        for c in theme.ACCENT_PRESETS:
            sel = c.lower() == cfg["accent"].lower()
            ctk.CTkButton(sw_row, text="", width=28, height=28, corner_radius=14, fg_color=c,
                          hover_color=theme.lighten(c, 0.2), border_width=3 if sel else 0,
                          border_color=p["text"],
                          command=lambda col=c: self._set_accent(col)).pack(side="left", padx=2)
        ctk.CTkButton(sw_row, text="＋", width=28, height=28, corner_radius=14,
                      fg_color=p["surface"], hover_color=p["accent_dark"], text_color=p["text"],
                      command=self._pick_accent).pack(side="left", padx=2)

        r = self._row(card, "Розмір тексту")
        self._fs_label = ctk.CTkLabel(r, text=str(cfg["font_size"]), text_color=p["muted"], width=24)
        self._fs_label.grid(row=0, column=2, padx=(8, 0))
        self._slider(r, 11, 20, 9, cfg["font_size"], self._on_font_size, 160
                     ).grid(row=0, column=1)

        r = self._row(card, "Плавні анімації")
        self._switch(r, cfg["animations"], "animations").grid(row=0, column=1)
        ctk.CTkFrame(card, height=6, fg_color="transparent").pack()

        card = self._card(sc, "Фон чату")
        r = self._row(card, "Фон")
        br = ctk.CTkFrame(r, fg_color="transparent")
        br.grid(row=0, column=1)
        self._button(br, "Візерунок", self._bg_pattern, primary=cfg["bg_mode"] == "pattern"
                     ).pack(side="left", padx=3)
        self._button(br, "Свій фон…", self._bg_choose, primary=cfg["bg_mode"] == "image"
                     ).pack(side="left", padx=3)
        r = self._row(card, "Затемнення власного фону")
        self._slider(r, 0, 0.8, 16, cfg["bg_dim"], self._on_bg_dim, 160).grid(row=0, column=1)
        ctk.CTkFrame(card, height=6, fg_color="transparent").pack()

        card = self._card(sc, "Сповіщення")
        r = self._row(card, "Сповіщення і звук")
        self._switch(r, cfg["notify"], "notify").grid(row=0, column=1)
        r = self._row(card, "Гучність")
        self._vol_label = ctk.CTkLabel(r, text=f"{int(cfg['volume'] * 100)}%",
                                       text_color=p["muted"], width=40)
        self._vol_label.grid(row=0, column=2, padx=(8, 0))
        self._slider(r, 0, 1, 20, cfg["volume"], self._on_volume, 160).grid(row=0, column=1)
        r = self._row(card, "Звук повідомлення")
        sr = ctk.CTkFrame(r, fg_color="transparent")
        sr.grid(row=0, column=1)
        self._button(sr, "▶", self._play_notify_sound, width=40).pack(side="left", padx=3)
        self._button(sr, "Обрати…", self._choose_sound).pack(side="left", padx=3)
        self._button(sr, "Скинути", self._reset_sound).pack(side="left", padx=3)
        cur = cfg["sound_file"].split("_", 1)[-1] if cfg["sound_file"] else DEFAULT_SOUND
        ctk.CTkLabel(card, text=f"Поточний: {cur}", text_color=p["muted"], anchor="w",
                     font=self.font(12)).pack(fill="x", padx=18, pady=(0, 12))

        card = self._card(sc, "Акаунт")
        r = self._row(card, f"Профіль: {self.username}")
        self._button(r, "Редагувати профіль", self.open_profile_edit, primary=True
                     ).grid(row=0, column=1)
        r = self._row(card, "Вийти з акаунта")
        self._button(r, "Вийти", self.logout, danger=True).grid(row=0, column=1)
        ctk.CTkFrame(card, height=6, fg_color="transparent").pack()

    def _on_toggle(self, key, sw):
        self.cfg[key] = bool(sw.get())
        self._save_cfg()

    def _on_mode(self, value):
        self.cfg["mode"] = "dark" if value == "Темна" else "light"
        self._save_cfg()
        self._rebuild_ui("settings")

    def _set_accent(self, color):
        if color.lower() == self.cfg["accent"].lower():
            return
        self.cfg["accent"] = color.lower()
        self._save_cfg()
        self._rebuild_ui("settings")

    def _pick_accent(self):
        res = colorchooser.askcolor(color=self.cfg["accent"], title="Колір теми")
        if res and res[1]:
            self._set_accent(res[1])

    def _on_font_size(self, v):
        self._fs_label.configure(text=str(int(v)))
        self.cfg["font_size"] = int(v)
        self._save_cfg()
        self.debounce("fs", 350, lambda: self._render_chat(self.current))

    def _on_volume(self, v):
        self.cfg["volume"] = round(float(v), 2)
        self._vol_label.configure(text=f"{int(v * 100)}%")
        self._save_cfg()
        if self.notify_snd is not None:
            self.notify_snd.set_volume(self.cfg["volume"])

    def _on_bg_dim(self, v):
        self.cfg["bg_dim"] = round(float(v), 2)
        self._save_cfg()
        self.debounce("dim", 150, self._update_bg)

    def _bg_pattern(self):
        self.cfg["bg_mode"] = "pattern"
        self._save_cfg()
        self._update_bg()
        self._rebuild_ui("settings", fade=False)

    def _bg_choose(self):
        path = filedialog.askopenfilename(
            title="Оберіть фон чату",
            filetypes=[("Зображення", "*.png *.jpg *.jpeg *.bmp *.webp")])
        if not path:
            return
        try:
            name = storage.import_asset(path, "backgrounds")   # зберігаємо копію в папці даних
        except OSError as e:
            self.sys_msg(f"Не вдалося зберегти фон: {e}")
            return
        old = self.cfg["bg_file"]
        self.cfg["bg_mode"], self.cfg["bg_file"] = "image", name
        self._load_bg_source()
        if self.bg_src is None:                                # файл не відкрився — повертаємо старий
            storage.remove_asset("backgrounds", name)
            self.cfg["bg_file"], self.cfg["bg_mode"] = old, "image" if old else "pattern"
            self._load_bg_source()
            self.sys_msg("Не вдалося відкрити зображення для фону")
        else:
            storage.remove_asset("backgrounds", old)
        self._save_cfg()
        self._update_bg()
        self._rebuild_ui("settings", fade=False)

    def _choose_sound(self):
        path = filedialog.askopenfilename(
            title="Оберіть звук сповіщення",
            filetypes=[("Аудіо", "*.mp3 *.wav *.ogg"), ("Усі файли", "*.*")])
        if not path:
            return
        try:
            name = storage.import_asset(path, "sounds")        # зберігаємо копію в папці даних
        except OSError as e:
            self.sys_msg(f"Не вдалося зберегти звук: {e}")
            return
        old = self.cfg["sound_file"]
        self.cfg["sound_file"] = name
        self._load_notify_sound()
        if self.notify_snd is None:                            # файл не відтворюється — лишаємо старий
            storage.remove_asset("sounds", name)
            self.cfg["sound_file"] = old
            self._load_notify_sound()
            self.sys_msg("Не вдалося завантажити цей звук (потрібен mp3, wav або ogg)")
        else:
            storage.remove_asset("sounds", old)
        self._save_cfg()
        self._play_notify_sound()
        self._rebuild_ui("settings", fade=False)

    def _reset_sound(self):
        storage.remove_asset("sounds", self.cfg["sound_file"])
        self.cfg["sound_file"] = ""
        self._load_notify_sound()
        self._save_cfg()
        self._rebuild_ui("settings", fade=False)

    def _rebuild_ui(self, reopen=None, fade=True):
        def do():
            try:
                self._close_toast(now=True)
                if self.recording:
                    self._stop_record(send=False)
                self.p = theme.make_palette(self.cfg["mode"], self.cfg["accent"])
                ctk.set_appearance_mode(self.cfg["mode"])
                self.configure(fg_color=self.p["bg"])
                self.ui_ready = False
                for st in list(self._tweens.values()):
                    if st.get("job"):
                        try:
                            self.after_cancel(st["job"])
                        except Exception:
                            pass
                self._tweens = {}
                for w in list(self.winfo_children()):
                    w.destroy()
                self.items, self.chat_rows, self._img_cache = [], {}, {}
                self.page = self.page_name = self._old_page = None
                self.pv = self.edit = None
                self.menu_open = False
                self._last_wrap = 0
                self._build_ui()
                if reopen == "settings":
                    self.open_settings(instant=True)
                elif reopen == "profile_edit":
                    self.open_profile_edit(instant=True)
            except Exception:
                set_alpha(self, 1.0)
                raise

        def start():
            if not fade:
                do()
                return

            def after_out():
                do()
                self.tween("fade", 220, lambda t: set_alpha(self, 0.1 + 0.9 * t))

            self.tween("fade", 120, lambda t: set_alpha(self, 1.0 - 0.9 * t), done=after_out)

        self.after(180, start)  # даємо кнопці закінчити свою анімацію натискання
