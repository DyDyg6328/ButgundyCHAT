"""Список чатів (ліва панель) і бічне меню ☰."""
import datetime
import theme

import customtkinter as ctk

from consts import GROUP, SIDEBAR_W


class SidebarMixin:
    def _build_chat_row(self, key):
        p = self.p
        row = ctk.CTkFrame(self.chat_list, fg_color=p["panel"], corner_radius=14, height=66)
        row.grid_propagate(False)
        row.grid_columnconfigure(1, weight=1)
        row.grid_rowconfigure((0, 1), weight=1)
        av = ctk.CTkLabel(row, text="", width=46, height=46, image=self.avatar_ctk(key, 46))
        av.grid(row=0, column=0, rowspan=2, padx=(10, 10), pady=10)
        name = ctk.CTkLabel(row, text="", anchor="w", font=self.font(14, "bold"),
                            text_color=p["text"])
        name.grid(row=0, column=1, sticky="sw")
        tm = ctk.CTkLabel(row, text="", font=self.font(11), text_color=p["muted"])
        tm.grid(row=0, column=2, sticky="se", padx=(4, 12))
        prev = ctk.CTkLabel(row, text="", anchor="w", font=self.font(12), text_color=p["muted"])
        prev.grid(row=1, column=1, sticky="nw")
        badge = ctk.CTkLabel(row, text="", width=22, height=22, corner_radius=11,
                             fg_color=p["accent"], text_color=p["on_accent"],
                             font=self.font(11, "bold"))
        badge.grid(row=1, column=2, sticky="ne", padx=(4, 12))
        badge.grid_remove()
        self.chat_rows[key] = {"row": row, "av": av, "name": name, "time": tm,
                               "prev": prev, "badge": badge}
        row._fx_cur = p["panel"]
        for w in (row, av, name, tm, prev, badge):
            w.bind("<Button-1>", lambda e, k=key: self.switch_chat(k))
            w.bind("<Enter>", lambda e, k=key: self.after(5, lambda: self._hover_check(k)))
            w.bind("<Leave>", lambda e, k=key: self.after(25, lambda: self._hover_check(k)))
        self._refresh_row(key)

    def _row_base(self, key):
        return self.p["accent"] if key == self.current else self.p["panel"]

    def _hover_check(self, key):
        r = self.chat_rows.get(key)
        if not r:
            return
        inside = False
        try:
            x, y = self.winfo_pointerxy()
            w = self.winfo_containing(x, y)
            while w is not None:
                if w is r["row"]:
                    inside = True
                    break
                w = getattr(w, "master", None)
        except Exception:
            pass
        target = self._row_base(key)
        if inside and key != self.current:
            target = self.p["surface"]
        self._color_to(r["row"], "fg_color", target, 120)

    def _last_text(self, key):
        for rec in reversed(self.chats[key]["msgs"]):
            if rec["kind"] == "system":
                continue
            txt = {"text": rec.get("text", ""), "image": "📷 Зображення", "voice": "🎤 Голосове",
                   "audio": "🎵 " + rec.get("name", ""), "video": "🎬 " + rec.get("name", ""),
                   "file": "📎 " + rec.get("name", "")}.get(rec["type"], "")
            if rec["kind"] == "own":
                txt = "Ви: " + txt
            elif key == GROUP:
                txt = f"{self.users.get(rec.get('author'), '?')}: {txt}"
            return (txt if len(txt) <= 30 else txt[:29] + "…"), rec["ts"]
        return "", 0

    def _refresh_row(self, key):
        r = self.chat_rows.get(key)
        if not r:
            return
        p = self.p
        active = key == self.current
        txt, ts = self._last_text(key)
        fg_main = p["on_accent"] if active else p["text"]
        fg_mut = p["on_accent_muted"] if active else p["muted"]
        r["name"].configure(text=self._name_of(key), text_color=fg_main)
        r["prev"].configure(text=txt, text_color=fg_mut)
        r["time"].configure(
            text=datetime.datetime.fromtimestamp(ts).strftime("%H:%M") if ts else "",
            text_color=fg_mut)
        r["av"].configure(image=self.avatar_ctk(key, 46))
        n = self.chats[key]["unread"]
        if n:
            r["badge"].configure(text=str(n) if n < 100 else "99+",
                                 fg_color=p["on_accent"] if active else p["accent"],
                                 text_color=p["accent"] if active else p["on_accent"])
            r["badge"].grid()
        else:
            r["badge"].grid_remove()
        base = self._row_base(key)
        r["row"]._fx_cur = base
        r["row"].configure(fg_color=base)

    def _layout_chat_list(self):
        q = self.search_entry.get().strip().casefold()
        keys = [GROUP] + sorted(
            (k for k in self.chats if k != GROUP),
            key=lambda k: (-self._last_text(k)[1], self._name_of(k).casefold()))
        for r in self.chat_rows.values():
            r["row"].pack_forget()
        for k in keys:
            if k in self.chat_rows and (not q or q in self._name_of(k).casefold()):
                self.chat_rows[k]["row"].pack(fill="x", padx=6, pady=2)

    def _ensure_chat(self, key):
        if key not in self.chats:
            self.chats[key] = {"msgs": [], "unread": 0}
        if self.ui_ready and key not in self.chat_rows:
            self._build_chat_row(key)
            self._layout_chat_list()

    def switch_chat(self, key, force=False):
        self._close_menu()
        if key not in self.chats or (key == self.current and not force):
            return
        self.current = key
        self.chats[key]["unread"] = 0
        self._update_header()
        for k in list(self.chat_rows):
            self._refresh_row(k)
        self._render_chat(key, slide=True)

    def _update_header(self):
        if not self.ui_ready:
            return
        key = self.current
        self.h_name.configure(text=self._name_of(key))
        self.h_avatar.configure(image=self.avatar_ctk(key, 40))
        if key == GROUP:
            total = len(self.users) + (1 if self.my_id else 0)
            on = len(self.online) + (1 if self.my_id else 0)
            self.h_status.configure(text=f"{total} учасників, {on} в мережі",
                                    text_color=self.p["muted"])
        elif key in self.online:
            self.h_status.configure(text="в мережі", text_color=self.p["author"])
        else:
            self.h_status.configure(text="не в мережі", text_color=self.p["muted"])

    def _open_current_profile(self):
        if self.current != GROUP:
            self.open_profile_view(self.current)

    def _build_menu(self):
        p = self.p
        self.menu = ctk.CTkFrame(self, width=SIDEBAR_W, fg_color=p["panel"], corner_radius=0)
        self.menu.pack_propagate(False)
        head = ctk.CTkFrame(self.menu, fg_color=p["accent_dark"], corner_radius=0, height=150)
        head.pack(fill="x")
        head.pack_propagate(False)
        self.menu_banner = ctk.CTkLabel(head, text="", image=self._menu_header_image(),
                                        width=SIDEBAR_W, height=150)
        self.menu_banner.place(x=0, y=0)

        items = [("👤   Мій профіль", self.open_profile_edit),
                 ("⚙   Налаштування", self.open_settings),
                 ("🔄   Перепідключитися", self.reconnect),
                 ("🚪   Вийти з акаунта", self.logout)]
        for text, cmd in items:
            b = ctk.CTkButton(self.menu, text=text, anchor="w", height=48, corner_radius=0,
                              fg_color=p["panel"], hover_color=p["panel"], text_color=p["text"],
                              font=self.font(14),
                              command=lambda c=cmd: (self._close_menu(), self.after(150, c)))
            self._fx(b, p["panel"], p["surface"])
            b.pack(fill="x")
        ctk.CTkLabel(self.menu, text=f"Сервер: {self.cfg['server_host']}:{self.cfg['server_port']}", text_color=p["muted"],
                     font=self.font(11)).pack(side="bottom", pady=12)
        self.menu_x = -SIDEBAR_W
        self.menu.place(x=self.menu_x, y=0, relheight=1)

    def _menu_header_image(self):
        p = self.p
        prof = self.profiles.get(self.my_id) if self.my_id else None
        banner = prof.get("banner") if prof else None
        av = self.avatar_pil(self.my_id, 128) if self.my_id else None
        sub = "в мережі" if self.sock else "не в мережі"
        if self.is_admin:
            sub = "адміністратор · " + sub
        pil = theme.menu_header(banner, av, self.username, sub, SIDEBAR_W, 150,
                                p["accent_dark"], p["accent"])
        return self._ctk_image(pil, (SIDEBAR_W, 150))

    def _update_menu_header(self):
        if self.ui_ready and self.my_id:
            self.menu_banner.configure(image=self._menu_header_image())

    def toggle_menu(self):
        if self.menu_open:
            self._close_menu()
        else:
            self.menu_open = True
            self.menu.lift()
            self.menu_btn.configure(text="✕")
            self._slide_menu(0)

    def _close_menu(self):
        if self.menu_open:
            self.menu_open = False
            self.menu_btn.configure(text="☰")
            self._slide_menu(-SIDEBAR_W)

    def _slide_menu(self, target):
        start = self.menu_x

        def fn(t):
            self.menu_x = start + (target - start) * t
            self.menu.place(x=int(self.menu_x), y=0, relheight=1)

        self.tween("menu", 260, fn)
