"""Базові утиліти: шрифти, анімації (tween), аватарки, збереження налаштувань."""
import storage
import theme
import time

import customtkinter as ctk

from theme import mix
from consts import GROUP
from ui.helpers import ease_out


class BaseMixin:
    def font(self, size=13, weight="normal", slant="roman"):
        key = (size, weight, slant)
        f = self._fonts.get(key)
        if f is None:
            f = self._fonts[key] = ctk.CTkFont(size=size, weight=weight, slant=slant)
        return f

    def tween(self, key, ms, fn, ease=ease_out, done=None):
        """Плавна анімація: fn(t) викликається з t від 0 до 1. Той самий key скасовує попередню."""
        old = self._tweens.pop(key, None)
        if old and old.get("job"):
            try:
                self.after_cancel(old["job"])
            except Exception:
                pass
        if not self.cfg["animations"] or ms <= 0:
            try:
                fn(1.0)
            except Exception:
                pass
            if done:
                done()
            return
        st = {"job": None}
        self._tweens[key] = st
        t0 = time.perf_counter()

        def step():
            t = min(1.0, (time.perf_counter() - t0) * 1000.0 / ms)
            try:
                fn(ease(t))
            except Exception:
                if self._tweens.get(key) is st:
                    self._tweens.pop(key, None)
                return
            if t >= 1.0:
                if self._tweens.get(key) is st:
                    self._tweens.pop(key, None)
                if done:
                    done()
            else:
                st["job"] = self.after(15, step)

        step()

    def debounce(self, key, ms, fn):
        job = self._debounce_jobs.pop(key, None)
        if job:
            try:
                self.after_cancel(job)
            except Exception:
                pass
        self._debounce_jobs[key] = self.after(ms, fn)

    def _color_to(self, w, opt, target, ms=140):
        try:
            cur = getattr(w, "_fx_cur", None) or w.cget(opt)
        except Exception:
            cur = target
        if not (isinstance(cur, str) and cur.startswith("#")):
            cur = target

        def fn(t):
            c = mix(cur, target, t)
            w.configure(**{opt: c})
            w._fx_cur = c

        self.tween(("c", str(w), opt), ms, fn)

    def _fx(self, btn, base, hover):
        """Плавна зміна кольору кнопки при наведенні (замість миттєвої)."""
        btn._fx_cur = base
        btn.bind("<Enter>", lambda e: self._color_to(btn, "fg_color", hover), add="+")
        btn.bind("<Leave>", lambda e: self._color_to(btn, "fg_color", base), add="+")

    def _icon_btn(self, parent, text, command, base, hover, size=40, fsize=17):
        b = ctk.CTkButton(parent, text=text, width=size, height=size, corner_radius=size // 2,
                          fg_color=base, hover_color=base, text_color=self.p["text"],
                          font=self.font(fsize), command=command)
        self._fx(b, base, hover)
        return b

    def _name_of(self, key):
        if key == GROUP:
            return "Загальний чат"
        if key == self.my_id:
            return self.username
        return self.users.get(key, "?")

    def avatar_pil(self, key, size):
        pic = None if key == GROUP else self.avatars.get(key)
        return theme.avatar_image(size, name=self._name_of(key), picture=pic,
                                  group=(key == GROUP), accent=self.cfg["accent"])

    def avatar_ctk(self, key, size):
        ck = (key, self._name_of(key), self.avatar_have.get(key, 0), size, self.cfg["accent"])
        img = self._img_cache.get(ck)
        if img is None:
            pil = self.avatar_pil(key, size * 2)
            img = ctk.CTkImage(light_image=pil, dark_image=pil, size=(size, size))
            self._img_cache[ck] = img
        return img

    @staticmethod
    def _ctk_image(pil, size=None):
        size = size or pil.size
        return ctk.CTkImage(light_image=pil, dark_image=pil, size=size)

    def _save_cfg(self):
        storage.save_settings(self.cfg)
