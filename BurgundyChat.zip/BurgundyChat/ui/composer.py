"""Відправка повідомлень і файлів."""
from tkinter import filedialog
import base64
import io
import os
import threading

from PIL import Image

from consts import GROUP, IMG_EXT, MAX_FILE_MB


class ComposerMixin:
    def attach_file(self):
        if not self._can_send_to_current():
            return
        path = filedialog.askopenfilename(
            title="Оберіть файл",
            filetypes=[("Зображення, MP3, MP4", "*.png *.jpg *.jpeg *.gif *.bmp *.webp *.mp3 *.mp4"),
                       ("Зображення", "*.png *.jpg *.jpeg *.gif *.bmp *.webp"),
                       ("Аудіо MP3", "*.mp3"), ("Відео MP4", "*.mp4")])
        if path:
            self.send_path(path)

    def send_path(self, path):
        ext = os.path.splitext(path)[1].lower()
        target = self.current
        name = os.path.basename(path).replace("@", "_")
        if ext in IMG_EXT:
            try:
                pil = Image.open(path).convert("RGB")
                pil.thumbnail((1600, 1600))          # достатньо для перегляду на весь екран
                buf = io.BytesIO()
                pil.save(buf, format="JPEG", quality=88)
                raw = buf.getvalue()
            except Exception as e:
                self.sys_msg(f"Не вдалося відкрити зображення: {e}")
                return
            mid = self._new_mid()
            line = f"IMG@{mid}@{target}@{name}@{base64.b64encode(raw).decode('ascii')}\n"
            if self._send_raw(line):
                self.add_msg(target, "own", "image", raw=raw, name=name, mid=mid)
            else:
                self.sys_msg("Помилка відправлення: немає зʼєднання з сервером")
            return
        if ext not in (".mp3", ".mp4"):
            self.sys_msg("Можна надсилати зображення, MP3 і MP4")
            return
        try:
            if os.path.getsize(path) > MAX_FILE_MB * 1024 * 1024:
                self.sys_msg(f"Файл завеликий: максимум {MAX_FILE_MB} МБ")
                return
            with open(path, "rb") as f:
                raw = f.read()
        except OSError as e:
            self.sys_msg(f"Не вдалося прочитати файл: {e}")
            return
        if not self.sock:
            self.sys_msg("Помилка відправлення: немає зʼєднання з сервером")
            return
        mid = self._new_mid()
        self.add_msg(target, "own", "audio" if ext == ".mp3" else "video",
                     raw=raw, name=name, size=len(raw), mid=mid)

        def work():
            line = f"FILE@{mid}@{target}@{name}@{base64.b64encode(raw).decode('ascii')}\n"
            if not self._send_raw(line):
                self.incoming.put(("system", f"Не вдалося надіслати {name}"))

        threading.Thread(target=work, daemon=True).start()

    def _can_send_to_current(self):
        if self.current != GROUP and self.current not in self.online:
            self.sys_msg(f"{self._name_of(self.current)} зараз не в мережі")
            return False
        return True

    def send_text(self):
        text = self.message_entry.get().strip().replace("\n", " ")
        if not text:
            return
        if self.editing:                         # режим редагування наявного повідомлення
            self._commit_edit(text)
            return
        if not self._can_send_to_current():
            return
        target, mid = self.current, self._new_mid()
        if self._send_raw(f"MSG@{mid}@{target}@{text}\n"):
            self.add_msg(target, "own", "text", text=text, mid=mid)
        else:
            self.sys_msg("Помилка відправлення: немає зʼєднання з сервером")
        self.message_entry.delete(0, "end")
        self._update_action()

    def _update_action(self):
        if self.recording:
            return
        self.action_btn.configure(text="➤" if self.message_entry.get().strip() else "🎤")

    def _on_action(self):
        if self.recording:
            self._stop_record()
        elif self.message_entry.get().strip():
            self.send_text()
        else:
            self._start_record()
