"""Побудова головного вікна: бічна панель, шапка, чат, поле вводу."""
import tkinter as tk

import customtkinter as ctk

from consts import HEADER_H, SIDEBAR_W


class LayoutMixin:
    def _build_ui(self):
        p = self.p
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # ---------- ліва панель: пошук і список чатів
        self.sidebar = ctk.CTkFrame(self, width=SIDEBAR_W, fg_color=p["panel"], corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        self.sidebar.grid_rowconfigure(1, weight=1)
        self.sidebar.grid_columnconfigure(0, weight=1)

        top = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        top.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        top.grid_columnconfigure(1, weight=1)
        self.menu_btn = self._icon_btn(top, "☰", self.toggle_menu, p["panel"], p["surface"])
        self.menu_btn.grid(row=0, column=0)
        self.search_entry = ctk.CTkEntry(
            top, placeholder_text="Пошук", height=38, corner_radius=19, border_width=0,
            fg_color=p["surface"], text_color=p["text"], placeholder_text_color=p["muted"])
        self.search_entry.grid(row=0, column=1, sticky="ew", padx=(8, 0))
        self.search_entry.bind("<KeyRelease>", lambda e: self._layout_chat_list())

        self.chat_list = ctk.CTkScrollableFrame(
            self.sidebar, fg_color="transparent", corner_radius=0,
            scrollbar_button_color=p["accent_dark"], scrollbar_button_hover_color=p["accent"])
        self.chat_list.grid(row=1, column=0, sticky="nsew", padx=(4, 0))
        ctk.CTkFrame(self.sidebar, width=1, fg_color=p["border"], corner_radius=0
                     ).place(relx=1.0, rely=0, relheight=1, anchor="ne")

        # ---------- права частина: шапка, повідомлення, поле вводу
        area = ctk.CTkFrame(self, fg_color=p["bg"], corner_radius=0)
        area.grid(row=0, column=1, sticky="nsew")
        area.grid_columnconfigure(0, weight=1)
        area.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(area, fg_color=p["panel"], corner_radius=0, height=HEADER_H)
        header.grid(row=0, column=0, columnspan=2, sticky="ew")
        header.grid_propagate(False)
        header.grid_columnconfigure(2, weight=1)
        header.grid_rowconfigure((0, 1), weight=1)
        self.h_avatar = ctk.CTkLabel(header, text="", width=40, height=40,
                                     image=self.avatar_ctk(self.current, 40))
        self.h_avatar.grid(row=0, column=0, rowspan=2, padx=(16, 10))
        self.h_name = ctk.CTkLabel(header, text="", anchor="w", text_color=p["text"],
                                   font=self.font(15, "bold"))
        self.h_name.grid(row=0, column=1, sticky="sw")
        self.h_status = ctk.CTkLabel(header, text="", anchor="w", text_color=p["muted"],
                                     font=self.font(12))
        self.h_status.grid(row=1, column=1, sticky="nw")
        conn = ctk.CTkFrame(header, fg_color="transparent")
        conn.grid(row=0, column=3, rowspan=2, padx=16)
        self.status_dot = ctk.CTkFrame(conn, width=10, height=10, corner_radius=5,
                                       fg_color=p["err"])
        self.status_dot.pack(side="left", padx=(0, 6))
        self.status_label = ctk.CTkLabel(conn, text="офлайн", text_color=p["muted"],
                                         font=self.font(12))
        self.status_label.pack(side="left")
        ctk.CTkFrame(header, height=1, fg_color=p["border"], corner_radius=0
                     ).place(relx=0, rely=1.0, relwidth=1, anchor="sw")
        for w in (self.h_avatar, self.h_name, self.h_status):
            w.bind("<Button-1>", lambda e: self._open_current_profile())

        self.chat = tk.Canvas(area, bg=p["bg"], highlightthickness=0, bd=0, yscrollincrement=20)
        self.chat.grid(row=1, column=0, sticky="nsew")
        self.bg_item = self.chat.create_image(0, 0, anchor="nw")
        self.scrollbar = ctk.CTkScrollbar(
            area, command=self.chat.yview, fg_color=p["bg"], width=10,
            button_color=p["accent_dark"], button_hover_color=p["accent"])
        self.scrollbar.grid(row=1, column=1, sticky="ns")
        self.chat.configure(yscrollcommand=self._on_yscroll)
        self.chat.bind("<Configure>", self._on_chat_resize)
        self.chat.bind("<Button-1>", lambda e: self._close_menu())

        self.edit_bar = ctk.CTkFrame(area, fg_color=p["surface"], corner_radius=0, height=42)
        self.edit_bar.grid(row=2, column=0, columnspan=2, sticky="ew")
        self.edit_bar.grid_propagate(False)
        self.edit_bar.grid_columnconfigure(1, weight=1)
        self.edit_bar.grid_rowconfigure(0, weight=1)
        ctk.CTkLabel(self.edit_bar, text="✎", text_color=p["author"], font=self.font(16)
                     ).grid(row=0, column=0, padx=(16, 8))
        self.edit_label = ctk.CTkLabel(self.edit_bar, text="", anchor="w", text_color=p["muted"],
                                       font=self.font(13))
        self.edit_label.grid(row=0, column=1, sticky="ew")
        self._icon_btn(self.edit_bar, "✕", self._cancel_edit, p["surface"], p["accent_dark"],
                       size=30, fsize=13).grid(row=0, column=2, padx=12)
        self.edit_bar.grid_remove()

        bar = ctk.CTkFrame(area, fg_color=p["panel"], corner_radius=0)
        bar.grid(row=3, column=0, columnspan=2, sticky="ew")
        bar.grid_columnconfigure(1, weight=1)
        ctk.CTkFrame(bar, height=1, fg_color=p["border"], corner_radius=0
                     ).place(relx=0, rely=0, relwidth=1)
        self._icon_btn(bar, "📎", self.attach_file, p["panel"], p["surface"], size=44
                       ).grid(row=0, column=0, padx=(12, 4), pady=10)
        self.message_entry = ctk.CTkEntry(
            bar, placeholder_text="Напишіть повідомлення…", height=44, corner_radius=22,
            border_width=0, fg_color=p["surface"], text_color=p["text"],
            placeholder_text_color=p["muted"], font=self.font(14))
        self.message_entry.grid(row=0, column=1, sticky="ew", pady=10, padx=4)
        self.message_entry.bind("<Return>", lambda e: self.send_text())
        self.message_entry.bind("<Escape>", lambda e: self._cancel_edit())
        self.message_entry.bind("<KeyRelease>", lambda e: self._update_action())
        self.action_btn = ctk.CTkButton(
            bar, text="🎤", width=44, height=44, corner_radius=22, fg_color=p["accent"],
            hover_color=p["accent"], text_color=p["on_accent"], font=self.font(17),
            command=self._on_action)
        self._fx(self.action_btn, p["accent"], p["accent_hover"])
        self.action_btn.grid(row=0, column=2, padx=(4, 14))

        for key in self.chats:
            self._build_chat_row(key)
        self._layout_chat_list()
        self._build_menu()
        self._build_auth()
        self.ui_ready = True
        self._set_status(self.sock is not None)
        self._update_header()
        self._update_menu_header()
        self.after(60, self._first_render)

    def _first_render(self):
        self._update_bg()
        self._render_chat(self.current)
