"""Мережа: зʼєднання, протокол, оновлення користувачів."""
from socket import AF_INET
from socket import SOCK_STREAM
from socket import socket
import base64
import io
import json
import os
import queue
import threading

from PIL import Image
from PIL import ImageTk

import server
from consts import GROUP, LOCAL_HOSTS


class NetMixin:
    def connect_to_server(self, first_line=None, autostart=True, quiet=False):
        """autostart — дозволити запуск вбудованого сервера; quiet — не показувати помилку."""
        self._close_socket()
        self._set_status(False, "підключення…")
        host, port = self.cfg["server_host"], self.cfg["server_port"]
        threading.Thread(target=self._connect_worker,
                         args=(first_line, host, port, autostart, quiet), daemon=True).start()

    def reconnect(self):
        self.connect_to_server(first_line=self.login_line)

    @staticmethod
    def _dial(host, port):
        sock = socket(AF_INET, SOCK_STREAM)
        sock.settimeout(5)
        try:
            sock.connect((host, port))
        except OSError:
            sock.close()
            raise
        sock.settimeout(None)
        return sock

    def _open_socket(self, host, port, autostart):
        """Підключається до сервера; якщо на цьому комп'ютері його ще немає — запускає свій."""
        try:
            return self._dial(host, port)
        except ConnectionRefusedError:
            if not autostart or host not in LOCAL_HOSTS or not self._start_embedded_server(port):
                raise
            return self._dial(host, port)

    def _start_embedded_server(self, port):
        if self.embedded_server is not None:
            if self.embedded_server.port == port:
                return False
            self.embedded_server.stop()         # адресу змінили — піднімаємо сервер на новому порту
        try:
            srv = server.ChatServer("0.0.0.0", port)
            srv.start()
        except OSError:
            return False
        self.embedded_server = srv
        self.incoming.put(("info", f"Запущено вбудований сервер. Друзі підключаються за адресою "
                                   f"{server.lan_address()}:{port}"))
        return True

    def _connect_worker(self, first_line, host, port, autostart, quiet):
        try:
            sock = self._open_socket(host, port, autostart)
            self.sock = sock
            if first_line:
                sock.sendall((first_line + "\n").encode("utf-8"))
            self.incoming.put(("status", True))
        except OSError as e:
            if not quiet:
                self.incoming.put(("system", f"Не вдалося підключитися до {host}:{port}: {e}"))
            self.incoming.put(("status", False))
            return
        self.recv_message(sock)

    def _send_raw(self, data):
        if not self.sock:
            return False
        try:
            with self.send_lock:
                self.sock.sendall(data.encode("utf-8"))
            return True
        except OSError:
            return False

    def recv_message(self, sock):
        buf = bytearray()
        scan = 0
        try:
            while True:
                chunk = sock.recv(262144)
                if not chunk:
                    break
                buf += chunk
                while True:
                    i = buf.find(b"\n", scan)
                    if i < 0:
                        scan = len(buf)
                        break
                    line = bytes(buf[:i])
                    del buf[:i + 1]
                    scan = 0
                    if line.strip():
                        self.incoming.put(("line", line.decode("utf-8", errors="replace")))
        except OSError:
            pass
        finally:
            if sock is self.sock:
                self.incoming.put(("system", "Зʼєднання з сервером втрачено"))
                self.incoming.put(("status", False))

    def _process_queue(self):
        try:
            for _ in range(60):
                kind, payload = self.incoming.get_nowait()
                if kind == "line":
                    try:
                        self.handle_line(payload)
                    except Exception as e:  # одне погане повідомлення не ламає чат
                        print("Помилка обробки повідомлення:", repr(e))
                elif kind == "system":
                    self.sys_msg(payload)
                    if self.auth_visible:
                        self._auth_error(payload)
                elif kind == "info":
                    self.sys_msg(payload)
                    if self.auth_visible:
                        self._auth_info(payload)
                elif kind == "status":
                    self._set_status(payload)
                    if not payload:
                        self.online = set()
                        self._update_header()
                        for k in list(self.chat_rows):
                            self._refresh_row(k)
        except queue.Empty:
            pass
        self.after(60, self._process_queue)

    def _set_status(self, online, text=None):
        if text is None:
            text = "онлайн" if online else "офлайн"
        color = (self.p["ok"] if online else
                 self.p["muted"] if "підключ" in text else self.p["err"])
        self.status_dot.configure(fg_color=color)
        self.status_label.configure(text=text)

    def _close_socket(self):
        sock, self.sock = self.sock, None
        if sock:
            try:
                sock.close()
            except OSError:
                pass

    def _want_avatar(self, uid, rev):
        if self.avatar_have.get(uid) == rev:
            return
        if rev == 0:
            self.avatars[uid] = None
            self.avatar_have[uid] = 0
            return
        if self.avatar_wait.get(uid) != rev:
            self.avatar_wait[uid] = rev
            self._send_raw(f"AVATAR_GET@{uid}\n")

    def _update_users(self, rows):
        users, online = {}, set()
        for row in rows:
            uid, name, is_on = str(row[0]), row[1], bool(row[2])
            rev = int(row[3]) if len(row) > 3 else 0
            if uid == self.my_id:
                self.username = name
                self._want_avatar(uid, rev)
                continue
            users[uid] = name
            if is_on:
                online.add(uid)
            self._want_avatar(uid, rev)
        self.users, self.online = users, online
        for uid in users:
            self._ensure_chat(uid)
        for k in list(self.chat_rows):
            self._refresh_row(k)
        self._layout_chat_list()
        self._update_header()
        self._update_menu_header()
        if self.pv and "status" in self.pv:
            self._fill_profile_view()

    def _on_avatar(self, uid, rev, b64):
        self.avatars[uid] = self._decode_pil(b64)
        self.avatar_have[uid] = rev
        for k in list(self.chat_rows):
            self._refresh_row(k)
        self._update_header()
        self._update_menu_header()
        for it in self.items:                        # аватарки біля повідомлень у групі
            if it.get("uid") == uid and it.get("av"):
                it["photo"] = ImageTk.PhotoImage(self.avatar_pil(uid, 32))
                self.chat.itemconfigure(it["av"], image=it["photo"])
        if self.pv and self.pv.get("uid") == uid and "head" in self.pv:
            self._fill_profile_view()
        if self.edit and uid == self.my_id and "head" in self.edit:
            self._refresh_edit_preview()

    @staticmethod
    def _decode_pil(b64):
        if not b64:
            return None
        try:
            return Image.open(io.BytesIO(base64.b64decode(b64))).convert("RGB")
        except Exception:
            return None

    def handle_line(self, line):
        cmd, _, rest = line.partition("@")

        if cmd == "AUTH_OK":
            data = json.loads(rest)
            self.my_id = str(data["id"])
            self.username = data["username"]
            self.is_admin = bool(data.get("admin"))
            if self.pending_cred:
                self.login_line = "LOGIN@" + json.dumps(
                    {"login": self.pending_cred[0], "password": self.pending_cred[1]})
                self.cfg["last_login"] = self.pending_cred[0]
                self._save_cfg()
                self.pending_cred = None
            self._hide_auth()
            self._profile_request(self.my_id)
            self._update_menu_header()

        elif cmd == "AUTH_ERR":
            if not self.auth_visible:
                self.login_line = None
                self._show_auth("login")
            self._auth_error(rest)

        elif cmd == "USERS":
            self._update_users(json.loads(rest))

        elif cmd == "AVATAR":
            uid, rev, b64 = rest.split("@", 2)
            self._on_avatar(uid, int(rev), b64)

        elif cmd == "PROFILE":
            data = json.loads(rest)
            uid = str(data["id"])
            self.profiles[uid] = {
                "bio": data.get("bio", ""), "avatar": self._decode_pil(data.get("avatar")),
                "banner": self._decode_pil(data.get("banner")),
                "song_name": data.get("song_name", ""), "has_song": bool(data.get("has_song"))}
            if uid == self.my_id:
                self._update_menu_header()
                if self.edit and "head" in self.edit:
                    self.edit["has_song"] = self.profiles[uid]["has_song"]
                    self.edit["old_song_name"] = self.profiles[uid]["song_name"]
                    self._refresh_edit_preview()
            if self.pv and self.pv.get("uid") == uid:
                self._fill_profile_view()

        elif cmd == "SONG":
            data = json.loads(rest)
            uid = str(data["id"])
            self.songs[uid] = (data.get("name", ""), base64.b64decode(data["b64"]))
            if self.want_song == uid:
                self.want_song = None
                if self.pv and self.pv.get("uid") == uid and "song_btn" in self.pv:
                    self._play(f"song{uid}", "music", self.songs[uid][1], self.pv["song_btn"])
                elif self.edit and "preview" in self.edit:
                    self._play("song-preview", "music", self.songs[uid][1], self.edit["preview"])

        elif cmd == "OK":
            if self.edit and "status" in self.edit:
                self.edit["status"].configure(text="Збережено ✓", text_color=self.p["ok"])
                self._profile_request(self.my_id)
            else:
                self.sys_msg(rest)

        elif cmd == "SYS":
            self.sys_msg(rest, chat=GROUP)

        elif cmd == "ERR":
            self.sys_msg(rest)
            if self.auth_visible:
                self._auth_error(rest)
            if self.edit and "status" in self.edit:
                self.edit["status"].configure(text=rest, text_color=self.p["err"])

        elif cmd in ("MSG", "IMG", "VOICE", "FILE"):
            self._handle_content(cmd, rest)

        elif cmd == "EDIT":
            self._on_remote_edit(rest)

        elif cmd == "DEL":
            self._on_remote_delete(rest)

    def _handle_content(self, cmd, rest):
        """Вхідне повідомлення: MSG@mid@автор@чат@текст, IMG/FILE/VOICE@mid@автор@чат@імʼя@дані."""
        nsplit = 3 if cmd == "MSG" else 4
        p = rest.split("@", nsplit)
        if len(p) != nsplit + 1:
            return
        mid, sender, target = p[0], p[1], p[2]
        chat = GROUP if target == GROUP else sender
        name = self.users.get(sender, "?")
        common = {"author": sender, "mid": mid}

        if cmd == "MSG":
            self.add_msg(chat, "other", "text", text=p[3], **common)
            preview = p[3]
        elif cmd == "IMG":
            try:
                raw = base64.b64decode(p[4])
                Image.open(io.BytesIO(raw)).verify()
            except Exception:
                self.sys_msg(f"{name} надіслав(ла) пошкоджене зображення", chat=chat)
                return
            self.add_msg(chat, "other", "image", raw=raw, name=p[3], **common)
            preview = "📷 Зображення"
        elif cmd == "VOICE":
            try:
                raw, dur = base64.b64decode(p[4]), float(p[3])
            except Exception:
                self.sys_msg(f"{name} надіслав(ла) пошкоджене голосове", chat=chat)
                return
            self.add_msg(chat, "other", "voice", raw=raw, dur=dur, **common)
            preview = "🎤 Голосове повідомлення"
        else:
            try:
                raw = base64.b64decode(p[4])
            except Exception:
                self.sys_msg(f"{name} надіслав(ла) пошкоджений файл", chat=chat)
                return
            fname = p[3]
            ext = os.path.splitext(fname)[1].lower()
            mtype = "audio" if ext == ".mp3" else "video" if ext == ".mp4" else "file"
            self.add_msg(chat, "other", mtype, raw=raw, name=fname, size=len(raw), **common)
            preview = ("🎵 " if mtype == "audio" else "🎬 ") + fname

        self._notify(chat, sender, name, preview)
