# Burgundy Chat

**A Telegram-style desktop chat written in Python.** Group and private conversations, voice messages, images with a fullscreen viewer, mp3/mp4 sharing, profiles with a banner and a profile song, light/dark themes with a custom accent color, and a built-in server — all in a single app you can run with a double-click or ship as a Windows `.exe`.

<p align="center">
  <img src="docs/chat-dark.png" width="48%" alt="Dark theme">
  <img src="docs/chat-light.png" width="48%" alt="Light theme">
</p>

## Features

**Messaging**
- A general chat plus a private chat with every user; a new private chat appears automatically when someone joins
- Text, images, voice messages (up to 60 s), and **mp3 / mp4 files** (up to 20 MB)
- **Edit and delete your own messages** from the right-click menu (edits show an "edited" mark)
- Click an image to open it **fullscreen** (← / → to browse, Esc to close, save button)
- mp3 files and voice messages play inline with a progress bar; mp4 opens in your system player
- Unread counters, chat search, date separators, smooth animations everywhere

**Accounts & profiles**
- Username + password registration and login (PBKDF2-SHA256 with per-user salt)
- Permanent user IDs: renaming yourself never creates a "new user" for others
- Profile with **avatar, banner, bio and a profile song** (mp3)
- Admin moderation: the admin account sees messages that others deleted, marked with a red trash icon

**Look & feel**
- Dark / light theme and **any accent color** (8 presets + a color picker)
- Chat background: a generated doodle pattern by default, or **your own image** with adjustable dimming
- Desktop notifications in the bottom-right corner of the screen, with a sound
- **Custom notification sound**, volume slider, and spam protection (sound at most once every 4 s, toasts are merged)
- Your background and sound are **stored as copies** in the app data folder, so they survive moving or deleting the originals

**Zero-setup networking**
- No separate server needed: if nothing is listening on `localhost`, the app starts its own server when you sign in
- Friends connect by typing `host:port` in the "Server" field on the login screen
- A standalone server is also available (`server.py` / `server_only.bat`) and needs only the Python standard library

<p align="center">
  <img src="docs/profile.png" width="32%" alt="Profile">
  <img src="docs/settings.png" width="32%" alt="Settings">
  <img src="docs/lightbox.png" width="32%" alt="Fullscreen image viewer">
</p>

## Quick start

Requires **Python 3.10+**.

```bash
git clone https://github.com/<your-name>/BurgundyChat.git
cd BurgundyChat
pip install -r requirements.txt
python app.py
```

On Windows you can simply double-click **`run.bat`** — it locates Python (even if it is not on `PATH`), installs missing dependencies and starts the app.

To chat with a friend on the same network, tell them the address shown in the chat after you sign in (for example `192.168.0.5:8080`). They enter it in the **Server** field on the login screen. Over the internet use a port forward on port 8080 or a VPN such as Tailscale/ZeroTier — traffic is **not encrypted**.

### Build a Windows executable

```bat
build_exe.bat
```

This runs PyInstaller (one-folder build) and produces `dist\BurgundyChat\BurgundyChat.exe`. Distribute the whole folder. If something looks wrong, `python app.py --selftest` prints a quick check of resource paths.

## Configuration

| What | Where |
|---|---|
| User data (settings, background, sound, server database, `error.log`) | `%APPDATA%\BurgundyChat` on Windows, `~/.local/share/BurgundyChat` on Linux, `~/Library/Application Support/BurgundyChat` on macOS |
| Override the data folder | environment variable `BURGUNDY_DATA` |
| Optional admin account | `CHAT_ADMIN_NAME` / `CHAT_ADMIN_PASSWORD`, or an `admin.json` file (`{"name": "...", "password": "..."}`) in the data folder. No credentials are stored in the code; without them there is no admin |
| Server database path | `CHAT_DB` |

## Project layout

```
app.py            entry point (python app.py, --selftest for diagnostics)
server.py         TCP chat server (SQLite); runs standalone or embedded in the app
storage.py        data folder, settings, saved background/sound, resource lookup (works in a .exe)
theme.py          palettes, generated pattern background, avatars, icons
consts.py         shared constants
ui/
  window.py       MainWindow — assembles the mixins below
  layout.py       main window layout        sidebar.py   chat list and side menu
  chat.py         message area, scrolling   bubbles.py   message bubbles
  composer.py     sending, attachments      messages.py  context menu, edit, delete
  media.py        recording and playback    lightbox.py  fullscreen image viewer
  notify.py       toast notifications       pages.py     page overlays and shared widgets
  settings.py     settings page             profile.py   profile view / editor
  auth.py         login and registration    net.py       connection and protocol
  base.py         animations, fonts, avatars
assets/           app icon and the default notification sound
```

The UI is a single `customtkinter` window split into focused mixin classes; the server is a plain `socket` + `threading` implementation with a line-based text protocol (`MSG`, `IMG`, `FILE`, `VOICE`, `EDIT`, `DEL`, `PROFILE_*`, …) where binary payloads are base64-encoded.

## Known limitations

- Messages are relayed live and **not stored on the server**: history is lost on restart and private messages reach only users who are online
- The admin sees deleted messages only if they arrived while the admin was online
- No transport encryption (TLS) — use a VPN outside a trusted network
- mp4 files are opened in the system player rather than played inside the chat

## Tech stack

Python · [CustomTkinter](https://github.com/TomSchimansky/CustomTkinter) · Pillow · pygame (audio) · sounddevice + NumPy (voice recording) · SQLite · PyInstaller

## License

Add a license of your choice (for example MIT) as `LICENSE`.
