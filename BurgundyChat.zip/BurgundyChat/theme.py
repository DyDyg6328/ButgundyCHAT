"""Тема: палітра, візерунок фону, аватари, іконки."""
import math
import random
from functools import lru_cache

from PIL import Image, ImageDraw, ImageFont, ImageOps

from consts import DEFAULT_ACCENT

ACCENT_PRESETS = ["#800020", "#b3123a", "#c2185b", "#7b1fa2",
                  "#3f51b5", "#1976d2", "#00897b", "#ef6c00"]

# ----------------------------------------------------------------------- Кольори
def _rgb(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def _hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v)))) for v in rgb)


def mix(a, b, t):
    return _hex([x + (y - x) * t for x, y in zip(_rgb(a), _rgb(b))])


def lighten(c, t):
    return mix(c, "#ffffff", t)


def darken(c, t):
    return mix(c, "#000000", t)


def make_palette(mode, accent):
    """Повна палітра. Для стандартного бордового акценту кольори такі самі, як були."""
    accent = accent.lower()
    if mode == "dark":
        bg = "#0a0a0a"
        if accent == DEFAULT_ACCENT:
            panel, surface, pill = "#130809", "#1d0d10", "#1a0a0d"
            dark, hover = "#4a0d1a", "#a3112f"
        else:
            panel, surface, pill = (mix(bg, accent, 0.075), mix(bg, accent, 0.14),
                                    mix(bg, accent, 0.11))
            dark, hover = mix(bg, accent, 0.5), lighten(accent, 0.18)
        p = dict(bg=bg, panel=panel, surface=surface, pill=pill,
                 accent_dark=dark, accent_hover=hover,
                 text="#f3e7e9", muted="#b79aa0", on_accent="#f3e7e9",
                 in_bubble=surface, border_soft=dark, border=dark,
                 author=lighten(accent, 0.35), track_in=dark)
    else:
        bg = "#f6f0f1"
        soft = mix("#ffffff", accent, 0.14)
        p = dict(bg=bg, panel="#ffffff", surface=mix("#ffffff", accent, 0.07),
                 pill=mix("#ffffff", accent, 0.12),
                 accent_dark=mix("#ffffff", accent, 0.22), accent_hover=darken(accent, 0.18),
                 text="#2a1117", muted="#86686f", on_accent="#ffffff",
                 in_bubble="#ffffff", border_soft=soft, border=soft,
                 author=accent, track_in=mix("#ffffff", accent, 0.22))
    p.update(accent=accent, out_bubble=accent,
             on_accent_muted=mix(accent, "#ffffff", 0.65),
             track_out=mix(accent, "#ffffff", 0.35),
             ok="#3ddc84", err="#ff4d5e", mode=mode)
    return p


# ----------------------------------------------------------- Візерунок фону
_KINDS = ["circle", "plus", "cross", "star", "heart", "triangle", "diamond",
          "wave", "plane", "bolt", "spiral", "dots", "ring"]


def _draw_glyph(kind, S, color, w):
    """Один значок у квадраті S×S (RGBA); усе вписано в коло, тому обертання безпечне."""
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c, r = S / 2, S * 0.40

    def line(pts, close=True):
        pts = list(pts) + ([pts[0]] if close else [])
        d.line(pts, fill=color, width=w, joint="curve")

    if kind == "circle":
        d.ellipse((c - r * .8, c - r * .8, c + r * .8, c + r * .8), outline=color, width=w)
    elif kind == "ring":
        d.ellipse((c - r, c - r, c + r, c + r), outline=color, width=w)
        d.ellipse((c - r * .45, c - r * .45, c + r * .45, c + r * .45), outline=color, width=w)
    elif kind == "plus":
        line([(c - r * .8, c), (c + r * .8, c)], False)
        line([(c, c - r * .8), (c, c + r * .8)], False)
    elif kind == "cross":
        k = r * .62
        line([(c - k, c - k), (c + k, c + k)], False)
        line([(c - k, c + k), (c + k, c - k)], False)
    elif kind == "star":
        pts = []
        for i in range(10):
            rad = r if i % 2 == 0 else r * .42
            pts.append((c + rad * math.sin(i * math.pi / 5), c - rad * math.cos(i * math.pi / 5)))
        line(pts)
    elif kind == "heart":
        pts = []
        for i in range(64):
            t = i / 64 * 2 * math.pi
            x = 16 * math.sin(t) ** 3
            y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
            pts.append((c + x * r / 17, c + y * r / 17 + r * .05))
        line(pts)
    elif kind == "triangle":
        line([(c, c - r), (c + r * .9, c + r * .7), (c - r * .9, c + r * .7)])
    elif kind == "diamond":
        line([(c, c - r), (c + r * .7, c), (c, c + r), (c - r * .7, c)])
    elif kind == "wave":
        pts = [(c - r + i * (2 * r / 36), c + r * .35 * math.sin(i / 36 * 3 * math.pi * 2 / 1.5))
               for i in range(37)]
        line(pts, False)
    elif kind == "plane":
        line([(c - r, c - r * .1), (c + r, c - r * .75), (c + r * .25, c + r * .85),
              (c - r * .05, c + r * .1)])
    elif kind == "bolt":
        line([(c + r * .3, c - r), (c - r * .45, c + r * .1), (c + r * .05, c + r * .1),
              (c - r * .3, c + r)], False)
    elif kind == "spiral":
        pts = []
        for i in range(60):
            a = i / 60 * 4 * math.pi
            rad = r * (i / 60)
            pts.append((c + rad * math.cos(a), c + rad * math.sin(a)))
        line(pts, False)
    elif kind == "dots":
        for dx in (-r * .6, 0, r * .6):
            d.ellipse((c + dx - w, c - w, c + dx + w, c + w), fill=color)
    return img


@lru_cache(maxsize=8)
def _tile(mode, accent):
    pal = make_palette(mode, accent)
    bg = pal["bg"]
    col = mix(bg, accent, 0.38 if mode == "dark" else 0.19)
    rgba = _rgb(col) + (255,)
    T, cell, S = 440, 55, 176
    rng = random.Random(7)
    tile = Image.new("RGB", (T, T), bg)
    for gy in range(T // cell):
        for gx in range(T // cell):
            g = _draw_glyph(rng.choice(_KINDS), S, rgba, 8)
            g = g.rotate(rng.uniform(0, 360), resample=Image.BICUBIC)
            size = rng.randint(34, 44)
            g = g.resize((size, size), Image.LANCZOS)
            x = gx * cell + (cell - size) // 2 + rng.randint(-5, 5)
            y = gy * cell + (cell - size) // 2 + rng.randint(-5, 5)
            tile.paste(g, (x, y), g)
    return tile


def pattern_image(w, h, mode, accent):
    """Фон за замовчуванням: чорний (темна тема) або білий (світла) з візерунком."""
    tile = _tile(mode, accent.lower())
    T = tile.size[0]
    img = Image.new("RGB", (max(w, 1), max(h, 1)))
    for y in range(0, h, T):
        for x in range(0, w, T):
            img.paste(tile, (x, y))
    return img


def fit_bg(src, w, h, dim, mode):
    """Власний фон: підганяємо під розмір і трохи затемнюємо/освітлюємо для читабельності."""
    img = ImageOps.fit(src.convert("RGB"), (max(w, 1), max(h, 1)), Image.BILINEAR)
    overlay = Image.new("RGB", img.size, "#000000" if mode == "dark" else "#ffffff")
    return Image.blend(img, overlay, max(0.0, min(0.85, dim)))


# ------------------------------------------------------------------- Аватари
def _font(size):
    for name in ("segoeui.ttf", "arialbd.ttf", "arial.ttf", "DejaVuSans-Bold.ttf",
                 "LiberationSans-Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def initials(name):
    parts = [w for w in name.replace("_", " ").replace(".", " ").split() if w]
    if not parts:
        return "?"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][0] + parts[1][0]).upper()


def avatar_image(size, name="", picture=None, group=False, accent=DEFAULT_ACCENT):
    """Круглий аватар (RGBA): фото, ініціали або значок групи."""
    S = size * 4
    if picture is not None:
        pic = ImageOps.fit(picture.convert("RGB"), (S, S), Image.LANCZOS)
    else:
        shades = [accent, lighten(accent, 0.15), darken(accent, 0.2),
                  mix(accent, "#444444", 0.3), mix(accent, "#ffffff", 0.2), darken(accent, 0.4)]
        color = accent if group else shades[sum(map(ord, name)) % len(shades)]
        pic = Image.new("RGB", (S, S), color)
        d = ImageDraw.Draw(pic)
        if group:
            for dx, sc in ((-0.14, 0.9), (0.14, 1.0)):
                cx, cy = S * (0.5 + dx), S * 0.40
                rr = S * 0.11 * sc
                d.ellipse((cx - rr, cy - rr, cx + rr, cy + rr), fill="#ffffff")
                d.ellipse((cx - S * .17 * sc, S * .58, cx + S * .17 * sc, S * .58 + S * .30),
                          fill="#ffffff")
        else:
            text = initials(name)
            font = _font(int(S * (0.42 if len(text) == 1 else 0.36)))
            box = d.textbbox((0, 0), text, font=font)
            d.text(((S - (box[2] - box[0])) / 2 - box[0], (S - (box[3] - box[1])) / 2 - box[1]),
                   text, font=font, fill="#ffffff")
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, S - 1, S - 1), fill=255)
    pic = pic.convert("RGBA")
    pic.putalpha(mask)
    return pic.resize((size, size), Image.LANCZOS)


def banner_header(img, w, h):
    """Банер під шапку меню: підганяємо й затемнюємо низ, щоб читався текст."""
    base = ImageOps.fit(img.convert("RGB"), (w, h), Image.LANCZOS)
    grad = Image.linear_gradient("L").resize((w, h)).point(lambda v: int(v * 0.72))
    return Image.composite(Image.new("RGB", (w, h), "#000000"), base, grad)


def fmt_size(n):
    for unit in ("Б", "КБ", "МБ"):
        if n < 1024 or unit == "МБ":
            return f"{n:.0f} {unit}" if unit == "Б" else f"{n:.1f} {unit}"
        n /= 1024


def default_banner(w, h, c1, c2):
    """Градієнтний банер, коли власного немає."""
    mask = Image.linear_gradient("L").resize((w, h))
    return Image.composite(Image.new("RGB", (w, h), c2), Image.new("RGB", (w, h), c1), mask)


def profile_header(banner, avatar_rgba, W, bh, av, bg, c1, c2):
    """Банер із заокругленими верхніми кутами й аватаром, що заходить на нього знизу."""
    over = av // 2
    img = Image.new("RGB", (W, bh + over), bg)
    top = (ImageOps.fit(banner.convert("RGB"), (W, bh), Image.LANCZOS)
           if banner is not None else default_banner(W, bh, c1, c2))
    mask = Image.new("L", (W * 3, bh * 3), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, W * 3 - 1, bh * 3 + 80), radius=54, fill=255)
    img.paste(top, (0, 0), mask.resize((W, bh), Image.LANCZOS))
    cx, cy, ring = 24 + av // 2, bh, av // 2 + 5
    ImageDraw.Draw(img).ellipse((cx - ring, cy - ring, cx + ring, cy + ring), fill=bg)
    if avatar_rgba is not None:
        img.paste(avatar_rgba, (24, bh - av // 2), avatar_rgba)
    return img


def menu_header(banner, avatar_rgba, name, sub, w, h, c1, c2, scale=2):
    """Шапка бічного меню одним зображенням (банер + аватар + імʼя), щоб не було «плям» під текстом."""
    W, H = w * scale, h * scale
    src = banner if banner is not None else default_banner(W, H, c1, c2)
    base = banner_header(src, W, H)
    if avatar_rgba is not None:
        av = avatar_rgba.resize((64 * scale, 64 * scale), Image.LANCZOS)
        base.paste(av, (16 * scale, 20 * scale), av)
    d = ImageDraw.Draw(base)
    d.text((16 * scale, 98 * scale), name, font=_font(17 * scale), fill="#ffffff")
    d.text((16 * scale, 124 * scale), sub, font=_font(12 * scale), fill="#e6d3d7")
    return base


def trash_icon(size, color):
    """Іконка кошика (RGBA) — позначка видалених повідомлень, яку бачить адміністратор."""
    S = size * 8
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = _rgb(color) + (255,)
    w = max(3, S // 11)
    d.rounded_rectangle((S * .14, S * .24, S * .86, S * .32), radius=S * .03, fill=c)       # кришка
    d.rounded_rectangle((S * .36, S * .10, S * .64, S * .25), radius=S * .05, outline=c, width=w)  # ручка
    d.polygon([(S * .22, S * .38), (S * .78, S * .38), (S * .72, S * .92), (S * .28, S * .92)], fill=c)
    for x in (.40, .50, .60):                                                               # смужки
        d.line([(S * x, S * .48), (S * x, S * .82)], fill=(0, 0, 0, 0), width=w)
    return img.resize((size, size), Image.LANCZOS)
