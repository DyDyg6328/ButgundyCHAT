@echo off
setlocal
cd /d "%~dp0"

rem --- look for a working Python (the Microsoft Store stub fails this check) ---
set "PYC="
set "PYA="
py -3 -c "import sys" >nul 2>nul
if not errorlevel 1 (
    set "PYC=py"
    set "PYA=-3"
    goto found
)
python -c "import sys" >nul 2>nul
if not errorlevel 1 (
    set "PYC=python"
    goto found
)
for /d %%D in ("%LocalAppData%\Programs\Python\Python3*") do if exist "%%D\python.exe" set "PYC=%%D\python.exe"
if defined PYC goto found
for /d %%D in ("%ProgramFiles%\Python3*") do if exist "%%D\python.exe" set "PYC=%%D\python.exe"
if defined PYC goto found

echo Python was not found on this computer.
echo Install Python 3.10+ from https://www.python.org/downloads/ and run this file again.
start https://www.python.org/downloads/
pause
exit /b 1

:found
echo Using Python: %PYC% %PYA%

echo Installing build tools...
"%PYC%" %PYA% -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fail
echo Building BurgundyChat.exe ...
"%PYC%" %PYA% -m PyInstaller --noconfirm --clean --windowed --name BurgundyChat --icon assets\icon.ico --add-data "assets;assets" --collect-all customtkinter --hidden-import PIL._tkinter_finder app.py
if errorlevel 1 goto fail
echo.
echo Done: dist\BurgundyChat\BurgundyChat.exe
echo Copy the whole folder dist\BurgundyChat to share the app.
pause
exit /b 0
:fail
echo Build failed.
pause
exit /b 1
