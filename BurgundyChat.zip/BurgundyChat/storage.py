"""Де живуть дані програми: папка даних, налаштування, збережені фон і звук."""
import datetime
import json
import os
import shutil
import sys
import traceback
import uuid

from consts import DEFAULT_ACCENT, DEFAULT_HOST, DEFAULT_PORT

APP_NAME = "BurgundyChat"
BASE_DIR = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(__file__))
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

DEFAULTS = {
    "mode": "dark",              # dark / light
    "accent": DEFAULT_ACCENT,
    "bg_mode": "pattern",        # pattern / image
    "bg_file": "",               # імʼя збереженої копії фону (папка backgrounds)
    "bg_dim": 0.35,              # затемнення власного фону
    "notify": True,
    "volume": 0.35,              # гучність звуку сповіщень (0..1)
    "sound_file": "",            # імʼя збереженої копії звуку (папка sounds); порожньо = стандартний
    "animations": True,
    "font_size": 14,
    "last_login": "",
    "server_host": DEFAULT_HOST,
    "server_port": DEFAULT_PORT,
}


def resource(*parts):
    """Файл, що йде разом із програмою (assets/…); працює і з .exe."""
    return os.path.join(BASE_DIR, *parts)


def data_dir():
    """Папка для даних користувача (налаштування, фон, звук, база сервера)."""
    root = os.environ.get("BURGUNDY_DATA")
    if not root:
        if sys.platform == "win32":
            base = os.environ.get("APPDATA") or os.path.expanduser("~")
        elif sys.platform == "darwin":
            base = os.path.expanduser("~/Library/Application Support")
        else:
            base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
        root = os.path.join(base, APP_NAME)
    os.makedirs(root, exist_ok=True)
    return root


def db_file():
    return os.environ.get("CHAT_DB") or os.path.join(data_dir(), "chat_users.db")


def settings_file():
    return os.path.join(data_dir(), "chat_settings.json")


def admin_credentials():
    """Логін і пароль адміністратора: змінні CHAT_ADMIN_NAME/CHAT_ADMIN_PASSWORD або файл
    admin.json у папці даних ({"name": "...", "password": "..."}). Немає ні того, ні того —
    адміністратора немає. У коді й у репозиторії паролів не зберігається."""
    name, password = os.getenv("CHAT_ADMIN_NAME", ""), os.getenv("CHAT_ADMIN_PASSWORD", "")
    if not (name and password):
        try:
            with open(os.path.join(data_dir(), "admin.json"), encoding="utf-8") as f:
                data = json.load(f)
            name, password = str(data.get("name", "")).strip(), str(data.get("password", ""))
        except (OSError, ValueError, AttributeError):
            return None
    return (name, password) if name and password else None


def default_sound():
    for path in (resource("assets", "AxeMessage.mp3"), resource("AxeMessage.mp3")):
        if os.path.isfile(path):
            return path
    return ""


# ------------------------------------------------------- Збережені файли (фон, звук)
def asset_path(kind, name):
    return os.path.join(data_dir(), kind, name) if name else ""


def import_asset(src, kind):
    """Копіює вибраний файл у папку даних, щоб він не зникав, якщо оригінал перенесуть."""
    folder = os.path.join(data_dir(), kind)
    os.makedirs(folder, exist_ok=True)
    name = f"{uuid.uuid4().hex[:8]}_{os.path.basename(src)}"
    shutil.copyfile(src, os.path.join(folder, name))
    return name


def remove_asset(kind, name):
    path = asset_path(kind, name)
    if path and os.path.isfile(path):
        try:
            os.remove(path)
        except OSError:
            pass


# ----------------------------------------------------------------- Налаштування
def load_settings():
    data = dict(DEFAULTS)
    try:
        with open(settings_file(), encoding="utf-8") as f:
            saved = json.load(f)
    except (OSError, ValueError):
        return data
    if not isinstance(saved, dict):
        return data
    for key, default in DEFAULTS.items():
        val = saved.get(key)
        if isinstance(default, bool):
            ok = isinstance(val, bool)
        elif isinstance(default, float):
            ok = isinstance(val, (int, float)) and not isinstance(val, bool)
        elif isinstance(default, int):
            ok = isinstance(val, int) and not isinstance(val, bool)
        else:
            ok = isinstance(val, str)
        if ok:
            data[key] = val
    # старі версії зберігали лише шлях до файлу — переносимо в папку даних
    for old, new, kind in (("bg_path", "bg_file", "backgrounds"), ("sound_path", "sound_file", "sounds")):
        path = saved.get(old)
        if path and not data[new] and isinstance(path, str) and os.path.isfile(path):
            try:
                data[new] = import_asset(path, kind)
            except OSError:
                pass
    return data


def save_settings(cfg):
    try:
        with open(settings_file(), "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def migrate_legacy():
    """Файли, які старі версії клали поруч зі скриптами, копіюємо в папку даних (один раз)."""
    if getattr(sys, "frozen", False):
        return
    for name in ("chat_settings.json", "chat_users.db"):
        old, new = os.path.join(SCRIPT_DIR, name), os.path.join(data_dir(), name)
        if os.path.isfile(old) and not os.path.isfile(new):
            try:
                shutil.copyfile(old, new)
            except OSError:
                pass


def log_exception(exc_type, exc, tb):
    """Пише помилку у файл error.log (для .exe без консолі)."""
    try:
        with open(os.path.join(data_dir(), "error.log"), "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}]\n")
            f.write("".join(traceback.format_exception(exc_type, exc, tb)))
    except OSError:
        pass
